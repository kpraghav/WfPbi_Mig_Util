const API = '/api/migration';

export async function analyzeMigration(files) {
  const fd = new FormData();
  files.forEach(f => fd.append('files', f));
  const res = await fetch(`${API}/analyze`, { method: 'POST', body: fd });
  if (!res.ok) throw new Error(`Server error: ${res.status}`);
  return res.json();
}

export async function generateRdlBundle(files) {
  const fd = new FormData();
  files.forEach(f => fd.append('files', f));
  const res = await fetch(`${API}/generate-rdl`, { method: 'POST', body: fd });
  if (!res.ok) throw new Error(`RDL generation failed: ${res.status}`);
  const blob = await res.blob();
  downloadBlob(blob, 'webfocus_rdl_bundle.zip');
}

export async function generateSingleRdl(file) {
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch(`${API}/generate-rdl-single`, { method: 'POST', body: fd });
  if (!res.ok) throw new Error(`RDL generation failed: ${res.status}`);
  const blob = await res.blob();
  const name = file.name.replace(/\.[^.]+$/, '') + '.rdl';
  downloadBlob(blob, name);
}

export async function exportDAX(c) { await postAndDownload(`${API}/export/dax`, c, 'migration_dax.dax'); }
export async function exportMQuery(c) { await postAndDownload(`${API}/export/m`, c, 'migration_m_queries.pq'); }
export async function exportReport(r) { await postAndDownload(`${API}/export/report`, r, 'migration_report.txt'); }
export async function healthCheck() { return (await fetch(`${API}/health`)).json(); }

async function postAndDownload(url, body, filename) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  downloadBlob(await res.blob(), filename);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function downloadJSON(data, filename) {
  downloadBlob(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), filename);
}
