import { useState, useCallback, useRef, useMemo } from "react";
import * as api from "./api.js";

const TABS = [
  { id: "upload", label: "Upload", icon: "↑" },
  { id: "analysis", label: "Analysis", icon: "◎" },
  { id: "mappings", label: "Mappings", icon: "⇄" },
  { id: "features", label: "Features", icon: "★" },
  { id: "output", label: "Output", icon: "◆" },
  { id: "export", label: "Export", icon: "↓" }
];

const STATUS_COLORS = {
  Converted: { bg: "#0d3320", text: "#34d399", border: "#065f46" },
  "Needs Review": { bg: "#3b2308", text: "#fbbf24", border: "#78350f" },
  Manual: { bg: "#1e1a3a", text: "#a78bfa", border: "#4c1d95" },
  Unsupported: { bg: "#3b0e0e", text: "#f87171", border: "#7f1d1d" }
};

const CAT_COLORS = {
  Measure: "#6366f1", Column: "#10b981", Filter: "#f59e0b", Parameter: "#a855f7",
  Relationship: "#06b6d4", Style: "#ec4899", Pagination: "#f97316", DrillDown: "#14b8a6",
  SelfService: "#8b5cf6", ActiveReport: "#f43f5e", ETL: "#84cc16", Query: "#0ea5e9",
  DialogueManager: "#d946ef", Connection: "#22d3ee"
};

export default function App() {
  const [tab, setTab] = useState("upload");
  const [files, setFiles] = useState([]);
  const [response, setResponse] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [backendStatus, setBackendStatus] = useState(null);
  const [rdlGenerating, setRdlGenerating] = useState(false);
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [outputView, setOutputView] = useState("dax");
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const conversions = response?.conversions || [];
  const summary = response?.summary || {};
  const featureCoverage = response?.featureCoverage || {};

  const allMappings = useMemo(() => {
    const result = [];
    conversions.forEach((c, ci) => {
      (c.mappings || []).forEach((m, mi) => {
        result.push({ ...m, fileIdx: ci, fileName: c.sourceFile, classification: c.sourceClassification });
      });
    });
    return result;
  }, [conversions]);

  const filteredMappings = useMemo(() => {
    return allMappings.filter(m =>
      (filterCat === "all" || m.category === filterCat) &&
      (filterStatus === "all" || m.status === filterStatus)
    );
  }, [allMappings, filterCat, filterStatus]);

  const categories = useMemo(() => {
    const cats = new Set();
    allMappings.forEach(m => { if (m.category) cats.add(m.category); });
    return ["all", ...Array.from(cats).sort()];
  }, [allMappings]);

  // Check backend health on mount
  useState(() => {
    api.healthCheck().then(d => setBackendStatus(d)).catch(() => setBackendStatus(null));
  });

  const handleFiles = useCallback((newFiles) => {
    const arr = Array.from(newFiles).filter(f => f.name.match(/\.(fex|mas|focexec|txt)$/i));
    if (!arr.length) { setError("Upload .fex, .mas, .focexec, or .txt files"); return; }
    setFiles(prev => [...prev, ...arr]);
    setError(null);
  }, []);

  const runAnalysis = useCallback(async () => {
    setProcessing(true); setError(null);
    try {
      const data = await api.analyzeMigration(files);
      setResponse(data);
      setTab("analysis");
    } catch (e) {
      setError("Backend error: " + e.message + ". Is the Java backend running on port 8080?");
    }
    setProcessing(false);
  }, [files]);

  const handleDrop = useCallback((e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); }, [handleFiles]);

  const generateRdl = useCallback(async () => {
    setRdlGenerating(true); setError(null);
    try {
      await api.generateRdlBundle(files);
    } catch (e) {
      setError("RDL generation error: " + e.message);
    }
    setRdlGenerating(false);
  }, [files]);

  // ═══════════════════════════════════════════════════════════════
  // Styles
  // ═══════════════════════════════════════════════════════════════
  const s = {
    root: { fontFamily: "'SF Mono','Fira Code','Cascadia Code',monospace", background: "#07080d", color: "#d4d4e0", minHeight: "100vh", display: "flex", flexDirection: "column" },
    header: { background: "linear-gradient(135deg,#0c0d18,#12081f)", borderBottom: "1px solid #1a1a30", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" },
    logoBox: { display: "flex", alignItems: "center", gap: "12px" },
    logoMark: { width: "38px", height: "38px", background: "linear-gradient(135deg,#4f46e5,#7c3aed)", borderRadius: "10px", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "900", fontSize: "14px", color: "#fff", letterSpacing: "-0.05em" },
    title: { fontSize: "15px", fontWeight: "800", color: "#fff", letterSpacing: "-0.02em" },
    subtitle: { fontSize: "10px", color: "#7c3aed", fontWeight: "600", letterSpacing: "0.06em", textTransform: "uppercase" },
    nav: { display: "flex", gap: "2px", background: "#0e0f18", borderRadius: "8px", padding: "3px" },
    navBtn: (active) => ({ padding: "7px 14px", border: "none", borderRadius: "6px", background: active ? "#4f46e5" : "transparent", color: active ? "#fff" : "#5a5a70", cursor: "pointer", fontSize: "11px", fontWeight: "700", fontFamily: "inherit", transition: "all 0.15s", display: "flex", alignItems: "center", gap: "5px" }),
    main: { flex: 1, padding: "20px 24px", maxWidth: "1280px", margin: "0 auto", width: "100%" },
    card: { background: "#0e0f18", border: "1px solid #1a1a30", borderRadius: "10px", padding: "20px", marginBottom: "14px" },
    cardTitle: { fontSize: "13px", fontWeight: "800", marginBottom: "14px", color: "#fff", display: "flex", alignItems: "center", gap: "8px" },
    btn: (v = "primary", small = false) => ({ padding: small ? "5px 12px" : "9px 18px", border: v === "primary" ? "none" : "1px solid #252540", borderRadius: "6px", background: v === "primary" ? "linear-gradient(135deg,#4f46e5,#7c3aed)" : "transparent", color: "#fff", cursor: "pointer", fontSize: small ? "11px" : "12px", fontWeight: "700", fontFamily: "inherit", transition: "all 0.15s", display: "inline-flex", alignItems: "center", gap: "5px" }),
    badge: (status) => { const c = STATUS_COLORS[status] || STATUS_COLORS.Unsupported; return { display: "inline-flex", padding: "2px 9px", borderRadius: "99px", fontSize: "10px", fontWeight: "700", fontFamily: "inherit", background: c.bg, color: c.text, border: `1px solid ${c.border}` }; },
    catBadge: (cat) => ({ display: "inline-flex", padding: "2px 8px", borderRadius: "99px", fontSize: "10px", fontWeight: "600", fontFamily: "inherit", background: (CAT_COLORS[cat] || "#666") + "18", color: CAT_COLORS[cat] || "#888", border: `1px solid ${(CAT_COLORS[cat] || "#666")}40` }),
    statGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: "10px", marginBottom: "16px" },
    statCard: { background: "#0a0b14", border: "1px solid #1a1a30", borderRadius: "8px", padding: "14px", textAlign: "center" },
    statVal: { fontSize: "26px", fontWeight: "900", color: "#fff", lineHeight: 1 },
    statLabel: { fontSize: "10px", color: "#5a5a70", marginTop: "4px", textTransform: "uppercase", letterSpacing: "0.06em" },
    code: { background: "#08091a", border: "1px solid #1a1a30", borderRadius: "8px", padding: "14px", fontSize: "11px", lineHeight: "1.7", overflow: "auto", maxHeight: "420px", whiteSpace: "pre-wrap", fontFamily: "inherit", color: "#b4b4c8" },
    table: { width: "100%", borderCollapse: "collapse", fontSize: "11px" },
    th: { textAlign: "left", padding: "8px 10px", borderBottom: "1px solid #1a1a30", color: "#5a5a70", fontWeight: "700", fontSize: "10px", textTransform: "uppercase", letterSpacing: "0.05em" },
    td: { padding: "8px 10px", borderBottom: "1px solid #0e0f18", verticalAlign: "top" },
    fileItem: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 12px", background: "#0a0b14", borderRadius: "8px", marginBottom: "5px", border: "1px solid #1a1a30" },
    fileIcon: (type) => ({ width: "28px", height: "28px", borderRadius: "5px", background: type === "mas" ? "linear-gradient(135deg,#059669,#10b981)" : "linear-gradient(135deg,#4f46e5,#7c3aed)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "9px", fontWeight: "900", color: "#fff" }),
    pillRow: { display: "flex", gap: "4px", flexWrap: "wrap", marginBottom: "12px" },
    pill: (active) => ({ padding: "4px 12px", border: "none", borderRadius: "99px", background: active ? "#4f46e5" : "#151628", color: active ? "#fff" : "#6a6a80", cursor: "pointer", fontSize: "10px", fontWeight: "700", fontFamily: "inherit" }),
    scrollBox: { maxHeight: "500px", overflowY: "auto" },
    featureCard: (on) => ({ background: on ? "#0d1a14" : "#0a0b14", border: `1px solid ${on ? "#065f46" : "#1a1a30"}`, borderRadius: "8px", padding: "12px", textAlign: "center" }),
    featureDot: (on) => ({ width: "8px", height: "8px", borderRadius: "50%", background: on ? "#10b981" : "#333", display: "inline-block", marginRight: "6px" }),
    alert: { background: "#3b0e0e", border: "1px solid #7f1d1d", borderRadius: "8px", padding: "12px", color: "#f87171", fontSize: "12px", marginBottom: "12px" },
    success: { background: "#0d3320", border: "1px solid #065f46", borderRadius: "8px", padding: "8px 12px", color: "#34d399", fontSize: "11px", display: "inline-flex", alignItems: "center", gap: "6px" },
    progressBar: { height: "5px", background: "#1a1a30", borderRadius: "3px", overflow: "hidden" },
    progressFill: (pct) => ({ height: "100%", width: `${pct}%`, background: pct > 70 ? "linear-gradient(90deg,#10b981,#34d399)" : pct > 40 ? "linear-gradient(90deg,#f59e0b,#fbbf24)" : "linear-gradient(90deg,#ef4444,#f87171)", borderRadius: "3px", transition: "width 0.4s" }),
  };

  // ═══════════════════════════════════════════════════════════════
  // Upload Tab
  // ═══════════════════════════════════════════════════════════════
  const UploadTab = () => (
    <div>
      {backendStatus && <div style={s.success}>● Backend connected — v{backendStatus.version || "3.0"}</div>}
      {!backendStatus && <div style={{ ...s.alert, marginTop: "8px" }}>Backend not detected at localhost:8080. Start it with: cd backend && mvn spring-boot:run</div>}
      {error && <div style={s.alert}>{error}</div>}

      <div style={{ ...s.card, marginTop: "12px" }}>
        <div style={s.cardTitle}>↑ Upload WebFocus Files</div>
        <div style={{ border: "2px dashed #252540", borderRadius: "10px", padding: "40px 20px", textAlign: "center", cursor: "pointer" }}
          onDrop={handleDrop} onDragOver={e => e.preventDefault()} onClick={() => fileInputRef.current?.click()}>
          <div style={{ fontSize: "28px", marginBottom: "8px", opacity: 0.4 }}>⬆</div>
          <div style={{ fontSize: "13px", fontWeight: "700", color: "#fff", marginBottom: "4px" }}>Drop WebFocus files or click to browse</div>
          <div style={{ fontSize: "11px", color: "#5a5a70" }}>.fex, .mas, .focexec, .txt — Self-service, Paginated, Active Reports, Dashboards, ETL</div>
          <input ref={fileInputRef} type="file" multiple accept=".fex,.mas,.focexec,.txt" style={{ display: "none" }} onChange={e => handleFiles(e.target.files)} />
        </div>
      </div>

      {files.length > 0 && <div style={s.card}>
        <div style={s.cardTitle}>◆ Queued ({files.length})</div>
        {files.map((f, i) => {
          const ext = f.name.split(".").pop().toLowerCase();
          return <div key={i} style={s.fileItem}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={s.fileIcon(ext)}>{ext.toUpperCase()}</div>
              <div>
                <div style={{ fontWeight: "700", color: "#fff", fontSize: "12px" }}>{f.name}</div>
                <div style={{ fontSize: "10px", color: "#5a5a70" }}>{(f.size / 1024).toFixed(1)} KB</div>
              </div>
            </div>
            <button style={{ background: "none", border: "none", color: "#5a5a70", cursor: "pointer", fontSize: "14px" }}
              onClick={() => setFiles(prev => prev.filter((_, j) => j !== i))}>✕</button>
          </div>;
        })}
        <div style={{ marginTop: "14px", display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <button style={{ ...s.btn(), background: "linear-gradient(135deg,#059669,#10b981)", padding: "12px 24px", fontSize: "13px" }} onClick={generateRdl} disabled={rdlGenerating || !files.length}>
            {rdlGenerating ? "⟳ Generating RDL files..." : "⬇ Generate RDL Bundle (ZIP)"}
          </button>
          <button style={s.btn()} onClick={runAnalysis} disabled={processing}>
            {processing ? "⟳ Analyzing..." : "◎ Analyze & Preview"}
          </button>
          <button style={s.btn("secondary")} onClick={() => { setFiles([]); setResponse(null); }}>Clear All</button>
        </div>
        <div style={{ marginTop: "8px", fontSize: "10px", color: "#5a5a70", lineHeight: "1.6" }}>
          <strong style={{ color: "#10b981" }}>Generate RDL Bundle</strong> — Directly produces .rdl files you open in Report Builder and publish to Report Server.<br/>
          <strong style={{ color: "#4f46e5" }}>Analyze & Preview</strong> — Shows detailed mapping analysis, DAX measures, and confidence scores before generating.
        </div>
      </div>}

      <div style={s.card}>
        <div style={s.cardTitle}>★ Supported WebFocus Features</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "8px", fontSize: "11px" }}>
          {[
            { t: "Report Types", items: "TABLE, GRAPH, Paginated, Self-Service (InfoAssist), Active Reports, Dashboards" },
            { t: "Data Operations", items: "DEFINE, COMPUTE, RECAP, RECOMPUTE, JOIN, MATCH FILE, COMBINE, HOLD chains" },
            { t: "Grouping", items: "BY, ACROSS (cross-tab), WITHIN, PAGE-BREAK, SUBTOTAL, COLUMN-TOTAL, ROW-TOTAL" },
            { t: "Parameters", items: "ACCEPT, PROMPT, -SET (local & global), TYPE, DEFAULT, allowed values" },
            { t: "Styling", items: "SET STYLE, WHEN conditions, BACKCOLOR, COLOR, FONT, GRID, conditional formatting" },
            { t: "Pagination", items: "PAGE-BREAK, HEADING/FOOTING, SUBHEAD/SUBFOOT, TABPAGENO, TABLASTPAGE, SET LINES" },
            { t: "Navigation", items: "Drill-down (FOCEXEC href), -RUN chains, -INCLUDE, HOLDLIST, Active Report pivot" },
            { t: "Functions (100+)", items: "IF/THEN/ELSE, DECODE, SUBSTR, EDIT, DATECVT, AYMD, DATEDIF, UPCASE, LOCASE, TRIM, CTRAN..." },
            { t: "Dialogue Manager", items: "-SET, -IF, -GOTO, -RUN, -REPEAT, -TYPE, -HTMLFORM, labels" }
          ].map((g, i) => <div key={i} style={{ background: "#08091a", borderRadius: "6px", padding: "10px", border: "1px solid #1a1a30" }}>
            <div style={{ color: "#7c3aed", fontWeight: "800", fontSize: "10px", marginBottom: "3px", textTransform: "uppercase", letterSpacing: "0.05em" }}>{g.t}</div>
            <div style={{ color: "#7a7a90", lineHeight: "1.5" }}>{g.items}</div>
          </div>)}
        </div>
      </div>
    </div>
  );

  // ═══════════════════════════════════════════════════════════════
  // Analysis Tab
  // ═══════════════════════════════════════════════════════════════
  const AnalysisTab = () => {
    if (!response) return <div style={{ ...s.card, textAlign: "center", padding: "40px", color: "#5a5a70" }}>Upload and analyze files first</div>;
    return <div>
      <div style={s.statGrid}>
        {[
          { v: summary.totalFiles, l: "Files", c: "#4f46e5" },
          { v: summary.totalMappings, l: "Mappings", c: "#7c3aed" },
          { v: summary.convertedMappings, l: "Converted", c: "#10b981" },
          { v: summary.reviewMappings, l: "Review", c: "#fbbf24" },
          { v: summary.unsupportedMappings || 0, l: "Manual", c: "#a78bfa" },
          { v: `${summary.avgConfidence}%`, l: "Confidence", c: summary.avgConfidence > 70 ? "#10b981" : "#fbbf24" }
        ].map((s2, i) => <div key={i} style={s.statCard}>
          <div style={{ ...s.statVal, color: s2.c }}>{s2.v}</div>
          <div style={s.statLabel}>{s2.l}</div>
        </div>)}
      </div>

      {summary.byClassification && Object.keys(summary.byClassification).length > 0 && <div style={s.card}>
        <div style={s.cardTitle}>◎ Report Classifications</div>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {Object.entries(summary.byClassification).map(([cls, count]) =>
            <div key={cls} style={{ background: "#08091a", border: "1px solid #1a1a30", borderRadius: "8px", padding: "10px 16px", textAlign: "center" }}>
              <div style={{ fontSize: "18px", fontWeight: "900", color: "#fff" }}>{count}</div>
              <div style={{ fontSize: "10px", color: "#7c3aed", fontWeight: "600" }}>{cls}</div>
            </div>
          )}
        </div>
      </div>}

      {summary.byCategory && Object.keys(summary.byCategory).length > 0 && <div style={s.card}>
        <div style={s.cardTitle}>⇄ Mappings by Category</div>
        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
          {Object.entries(summary.byCategory).sort((a, b) => b[1] - a[1]).map(([cat, count]) =>
            <div key={cat} style={{ ...s.catBadge(cat), padding: "4px 12px", fontSize: "11px" }}>{cat}: {count}</div>
          )}
        </div>
      </div>}

      <div style={s.card}>
        <div style={s.cardTitle}>◎ Per-File Analysis</div>
        {conversions.map((c, ci) => <div key={ci}
          style={{ background: selectedFile === ci ? "#141428" : "#0a0b14", border: `1px solid ${selectedFile === ci ? "#4f46e5" : "#1a1a30"}`, borderRadius: "8px", padding: "12px", marginBottom: "6px", cursor: "pointer" }}
          onClick={() => setSelectedFile(selectedFile === ci ? null : ci)}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={s.fileIcon(c.sourceType === "Master File" ? "mas" : "fex")}>{c.sourceType === "Master File" ? "MAS" : "FEX"}</div>
              <div>
                <div style={{ fontWeight: "700", color: "#fff", fontSize: "12px" }}>{c.sourceFile}</div>
                <div style={{ fontSize: "10px", color: "#5a5a70" }}>
                  {c.sourceClassification || c.sourceType} · {c.mappings.length} mappings
                </div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{ ...s.progressBar, width: "70px" }}><div style={s.progressFill(c.confidence)} /></div>
              <span style={{ fontSize: "11px", color: "#5a5a70", fontWeight: "700" }}>{c.confidence}%</span>
            </div>
          </div>

          {selectedFile === ci && <div style={{ marginTop: "12px", borderTop: "1px solid #1a1a30", paddingTop: "12px" }}>
            {/* Paginated Report info */}
            {c.paginatedReport && <div style={{ marginBottom: "10px" }}>
              <div style={{ fontSize: "10px", color: "#f97316", fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" }}>Paginated Report</div>
              <div style={{ fontSize: "11px", color: "#b4b4c8", lineHeight: "1.6" }}>
                {c.paginatedReport.groups?.length > 0 && <div>Groups: {c.paginatedReport.groups.map(g => g.fieldName + (g.pageBreakBefore ? " [PAGE-BREAK]" : "")).join(", ")}</div>}
                {c.paginatedReport.parameters?.length > 0 && <div>Parameters: {c.paginatedReport.parameters.map(p => "@" + p.name).join(", ")}</div>}
                {c.paginatedReport.header && <div>Header: {c.paginatedReport.header.textLines?.join(" | ")}</div>}
                {c.paginatedReport.footer && <div>Footer: {c.paginatedReport.footer.textLines?.join(" | ")}
                  {c.paginatedReport.footer.hasPageNumber && " [Page#]"}
                  {c.paginatedReport.footer.hasTotalPages && " [/Total]"}
                </div>}
              </div>
            </div>}

            {/* Self-Service info */}
            {c.selfServiceMapping && <div style={{ marginBottom: "10px" }}>
              <div style={{ fontSize: "10px", color: "#8b5cf6", fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" }}>Self-Service → PBI Interactive</div>
              <div style={{ fontSize: "11px", color: "#b4b4c8" }}>
                Source: {c.selfServiceMapping.sourceToolType} → Features: {c.selfServiceMapping.enabledFeatures?.join(", ")}
              </div>
            </div>}

            {/* Active Report info */}
            {c.activeReportMapping && <div style={{ marginBottom: "10px" }}>
              <div style={{ fontSize: "10px", color: "#f43f5e", fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" }}>Active Report → PBI Interactive</div>
              <div style={{ fontSize: "11px", color: "#b4b4c8" }}>
                Target: {c.activeReportMapping.targetType}
                {c.activeReportMapping.hasPivot && " · Pivot"}{c.activeReportMapping.hasRollup && " · Rollup"}
              </div>
            </div>}

            {/* Dataflow */}
            {c.dataflow && <div style={{ marginBottom: "10px" }}>
              <div style={{ fontSize: "10px", color: "#84cc16", fontWeight: "800", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" }}>ETL → PBI Dataflow</div>
              <div style={{ fontSize: "11px", color: "#b4b4c8" }}>
                {c.dataflow.name}: {c.dataflow.steps?.length} steps
              </div>
            </div>}

            {/* Mapping table */}
            <div style={{ ...s.scrollBox, maxHeight: "300px" }}>
              <table style={s.table}><thead><tr>
                <th style={s.th}>Category</th><th style={s.th}>Source</th><th style={s.th}>Target</th><th style={s.th}>Status</th>
              </tr></thead><tbody>
                {c.mappings.map((m, mi) => <tr key={mi}>
                  <td style={s.td}><span style={s.catBadge(m.category)}>{m.category || "—"}</span></td>
                  <td style={{ ...s.td, color: "#b4b4c8", maxWidth: "280px", wordBreak: "break-word", fontSize: "10px" }}>{m.source}</td>
                  <td style={{ ...s.td, color: "#6366f1", maxWidth: "280px", wordBreak: "break-word", fontSize: "10px" }}>{m.target}</td>
                  <td style={s.td}><span style={s.badge(m.status)}>{m.status}</span></td>
                </tr>)}
              </tbody></table>
            </div>
          </div>}
        </div>)}
      </div>
    </div>;
  };

  // ═══════════════════════════════════════════════════════════════
  // Mappings Tab
  // ═══════════════════════════════════════════════════════════════
  const MappingsTab = () => {
    if (!response) return <div style={{ ...s.card, textAlign: "center", padding: "40px", color: "#5a5a70" }}>No data yet</div>;
    return <div>
      <div style={s.pillRow}>
        <span style={{ fontSize: "10px", color: "#5a5a70", fontWeight: "700", padding: "5px 0" }}>STATUS:</span>
        {["all", "Converted", "Needs Review", "Manual"].map(st =>
          <button key={st} style={s.pill(filterStatus === st)} onClick={() => setFilterStatus(st)}>{st === "all" ? "All" : st}</button>
        )}
      </div>
      <div style={s.pillRow}>
        <span style={{ fontSize: "10px", color: "#5a5a70", fontWeight: "700", padding: "5px 0" }}>CATEGORY:</span>
        {categories.map(cat =>
          <button key={cat} style={s.pill(filterCat === cat)} onClick={() => setFilterCat(cat)}>{cat === "all" ? "All" : cat}</button>
        )}
      </div>
      <div style={{ fontSize: "11px", color: "#5a5a70", marginBottom: "10px" }}>
        Showing {filteredMappings.length} of {allMappings.length} mappings
      </div>
      <div style={s.card}>
        <div style={{ ...s.scrollBox, maxHeight: "600px" }}>
          <table style={s.table}><thead><tr>
            <th style={s.th}>File</th><th style={s.th}>Cat</th><th style={s.th}>WebFocus Source</th><th style={s.th}>Power BI Target</th><th style={s.th}>Status</th>
          </tr></thead><tbody>
            {filteredMappings.map((m, i) => <tr key={i}>
              <td style={{ ...s.td, fontSize: "10px", color: "#5a5a70", whiteSpace: "nowrap" }}>{m.fileName}</td>
              <td style={s.td}><span style={s.catBadge(m.category)}>{m.category || "—"}</span></td>
              <td style={{ ...s.td, color: "#b4b4c8", maxWidth: "260px", wordBreak: "break-word", fontSize: "10px" }}>{m.source}</td>
              <td style={{ ...s.td, color: "#6366f1", maxWidth: "260px", wordBreak: "break-word", fontSize: "10px" }}>{m.target}</td>
              <td style={s.td}><span style={s.badge(m.status)}>{m.status}</span></td>
            </tr>)}
          </tbody></table>
        </div>
      </div>
    </div>;
  };

  // ═══════════════════════════════════════════════════════════════
  // Features Tab
  // ═══════════════════════════════════════════════════════════════
  const FeaturesTab = () => {
    if (!response) return <div style={{ ...s.card, textAlign: "center", padding: "40px", color: "#5a5a70" }}>No data yet</div>;
    const features = [
      { key: "paginatedReports", label: "Paginated Reports", desc: "PAGE-BREAK, HEADING/FOOTING, SUBHEAD, page numbering, SET LINES, RECAP → PBI Paginated Report (RDL)" },
      { key: "selfService", label: "Self-Service", desc: "InfoAssist, Report Painter, interactive filtering/sorting/drill-down/pivot → PBI Interactive Report" },
      { key: "activeReports", label: "Active Reports", desc: "ARVERSION, HOLDLIST, interactive pivot/rollup/filters → PBI Report with Bookmarks & Slicers" },
      { key: "dashboards", label: "Dashboards", desc: "HTML Composite, -HTMLFORM, multi-report layouts → PBI Dashboard with pinned tiles" },
      { key: "parameters", label: "Parameters", desc: "ACCEPT, PROMPT, -SET variables → PBI Parameters & Slicers with defaults" },
      { key: "conditionalFormatting", label: "Conditional Formatting", desc: "SET STYLE WHEN, BACKCOLOR, COLOR → PBI conditional formatting rules" },
      { key: "drillDown", label: "Drill-Down", desc: "FOCEXEC hyperlinks, passed parameters → PBI Drill-through pages" },
      { key: "crossTab", label: "Cross-Tab (ACROSS)", desc: "ACROSS field → PBI Matrix visual with column groups" },
      { key: "holdChains", label: "HOLD Chains / ETL", desc: "Multi-step HOLD/PCHOLD → PBI Dataflow with transform steps" },
      { key: "dialogueManager", label: "Dialogue Manager", desc: "-IF/-GOTO/-RUN/-REPEAT/-TYPE → Power Automate flow or manual logic" }
    ];
    return <div>
      <div style={s.card}>
        <div style={s.cardTitle}>★ WebFocus Feature Detection & Migration Mapping</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
          {features.map(f => {
            const on = featureCoverage[f.key];
            return <div key={f.key} style={s.featureCard(on)}>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "6px" }}>
                <span style={s.featureDot(on)} />
                <span style={{ fontSize: "12px", fontWeight: "800", color: on ? "#10b981" : "#5a5a70" }}>{f.label}</span>
                <span style={{ fontSize: "10px", color: on ? "#10b981" : "#444", marginLeft: "auto" }}>{on ? "DETECTED" : "Not found"}</span>
              </div>
              <div style={{ fontSize: "10px", color: "#6a6a80", lineHeight: "1.5" }}>{f.desc}</div>
            </div>;
          })}
        </div>
      </div>
    </div>;
  };

  // ═══════════════════════════════════════════════════════════════
  // Output Tab
  // ═══════════════════════════════════════════════════════════════
  const OutputTab = () => {
    if (!response) return <div style={{ ...s.card, textAlign: "center", padding: "40px", color: "#5a5a70" }}>No output yet</div>;
    const views = [
      { id: "dax", label: "DAX Measures" }, { id: "mquery", label: "Power Query M" },
      { id: "paginated", label: "Paginated (RDL)" }, { id: "params", label: "Parameters" },
      { id: "visuals", label: "Visuals" }, { id: "cond", label: "Cond. Formatting" },
      { id: "drill", label: "Drill-Through" }, { id: "report", label: "Full Report" }
    ];
    return <div>
      <div style={s.pillRow}>
        {views.map(v => <button key={v.id} style={s.pill(outputView === v.id)} onClick={() => setOutputView(v.id)}>{v.label}</button>)}
      </div>
      <div style={s.card}>
        {outputView === "dax" && <pre style={s.code}>{conversions.flatMap(c => [
          `// ── ${c.sourceFile} ──`,
          ...c.powerBI.calculatedColumns?.map(cc => `// Calc Column (${cc.table})\n${cc.name} = ${cc.expression}`) || [],
          ...c.powerBI.measures?.map(m => `// ${m.source}\n${m.name} = ${m.expression}${m.formatString ? `\n// Format: ${m.formatString}` : ""}`) || [], ""
        ]).join("\n")}</pre>}

        {outputView === "mquery" && <pre style={s.code}>{conversions.flatMap(c =>
          c.powerBI.queries?.map(q => `// ${q.name} | ${q.source}\n${q.expression}\n`) || []
        ).join("\n")}</pre>}

        {outputView === "paginated" && <div style={s.scrollBox}>
          {conversions.filter(c => c.paginatedReport).map((c, i) => {
            const pr = c.paginatedReport;
            return <div key={i} style={{ marginBottom: "16px" }}>
              <div style={{ fontSize: "13px", fontWeight: "800", color: "#f97316", marginBottom: "8px" }}>{pr.reportName || c.sourceFile}</div>
              <pre style={{ ...s.code, fontSize: "11px" }}>{[
                `Page: ${pr.pageSetup?.pageWidth}"×${pr.pageSetup?.pageHeight}" ${pr.pageSetup?.orientation}`,
                pr.header ? `Header: ${pr.header.textLines?.join(" | ")}` : null,
                pr.footer ? `Footer: ${pr.footer.textLines?.join(" | ")}${pr.footer.hasPageNumber ? " [Page#]" : ""}${pr.footer.hasTotalPages ? " [/Total]" : ""}${pr.footer.hasRunDate ? " [Date]" : ""}` : null,
                `\nParameters (${pr.parameters?.length || 0}):`,
                ...(pr.parameters?.map(p => `  @${p.name} (${p.dataType})${p.defaultValue ? " = " + p.defaultValue : ""}`) || []),
                `\nGroups (${pr.groups?.length || 0}):`,
                ...(pr.groups?.map(g => `  ${g.fieldName}${g.pageBreakBefore ? " [PAGE-BREAK]" : ""}${g.hasFooter ? " [subtotals]" : ""}${g.repeatHeaderOnNewPage ? " [repeat-header]" : ""}`) || []),
                `\nBody Items (${pr.bodyItems?.length || 0}):`,
                ...(pr.bodyItems?.map(b => `  ${b.type}: ${b.name}`) || [])
              ].filter(Boolean).join("\n")}</pre>
            </div>;
          })}
          {conversions.filter(c => c.paginatedReport).length === 0 && <div style={{ color: "#5a5a70", textAlign: "center", padding: "24px" }}>No paginated reports detected</div>}
        </div>}

        {outputView === "params" && <div style={s.scrollBox}>
          <table style={s.table}><thead><tr>
            <th style={s.th}>Name</th><th style={s.th}>Type</th><th style={s.th}>PBI Type</th><th style={s.th}>Default</th><th style={s.th}>Source</th>
          </tr></thead><tbody>
            {conversions.flatMap(c => c.powerBI.parameters || []).map((p, i) => <tr key={i}>
              <td style={{ ...s.td, color: "#fff", fontWeight: "600" }}>{p.name}</td>
              <td style={s.td}>{p.dataType}</td>
              <td style={s.td}><span style={s.catBadge("Parameter")}>{p.pbiType}</span></td>
              <td style={s.td}>{p.defaultValue || "—"}</td>
              <td style={{ ...s.td, fontSize: "10px", color: "#5a5a70" }}>{p.source}</td>
            </tr>)}
          </tbody></table>
        </div>}

        {outputView === "visuals" && <div style={s.scrollBox}>
          {conversions.flatMap(c => c.powerBI.visualConfigs || []).map((vc, i) => <div key={i} style={{ ...s.fileItem, flexDirection: "column", alignItems: "flex-start", gap: "4px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
              <span style={{ fontWeight: "700", color: "#fff", fontSize: "12px" }}>{vc.type}</span>
              <span style={{ fontSize: "10px", color: "#5a5a70" }}>{vc.pageName || vc.source}</span>
            </div>
            <div style={{ fontSize: "10px", color: "#7a7a90" }}>Fields: {vc.fields?.join(", ")}</div>
            {vc.groupBy?.length > 0 && <div style={{ fontSize: "10px", color: "#7a7a90" }}>Group: {vc.groupBy.join(", ")}</div>}
            {vc.across && <div style={{ fontSize: "10px", color: "#7a7a90" }}>Matrix Column: {vc.across}</div>}
          </div>)}
        </div>}

        {outputView === "cond" && <div style={s.scrollBox}>
          {conversions.flatMap(c => c.powerBI.conditionalFormats || []).map((cf, i) => <div key={i} style={s.fileItem}>
            <div>
              <div style={{ fontSize: "11px", color: "#fff", fontWeight: "600" }}>{cf.targetField || "Table"}</div>
              {cf.condition && <div style={{ fontSize: "10px", color: "#f59e0b" }}>WHEN: {cf.condition}</div>}
              <div style={{ fontSize: "10px", color: "#7a7a90" }}>{cf.source}</div>
            </div>
            <div style={{ display: "flex", gap: "6px" }}>
              {cf.backgroundColor && <div style={{ width: "20px", height: "20px", borderRadius: "4px", background: cf.backgroundColor, border: "1px solid #333" }} />}
              {cf.fontColor && <div style={{ width: "20px", height: "20px", borderRadius: "4px", background: cf.fontColor, border: "1px solid #333" }} />}
            </div>
          </div>)}
          {conversions.flatMap(c => c.powerBI.conditionalFormats || []).length === 0 && <div style={{ color: "#5a5a70", textAlign: "center", padding: "24px" }}>No conditional formatting detected</div>}
        </div>}

        {outputView === "drill" && <div style={s.scrollBox}>
          {conversions.flatMap(c => c.powerBI.drillThroughPages || []).map((dt, i) => <div key={i} style={s.fileItem}>
            <div>
              <div style={{ fontSize: "11px", color: "#fff", fontWeight: "600" }}>{dt.pageName}</div>
              <div style={{ fontSize: "10px", color: "#14b8a6" }}>Field: {dt.sourceField} → {dt.targetReport}</div>
              {dt.passedFilters?.length > 0 && <div style={{ fontSize: "10px", color: "#7a7a90" }}>Filters: {dt.passedFilters.join(", ")}</div>}
            </div>
          </div>)}
          {conversions.flatMap(c => c.powerBI.drillThroughPages || []).length === 0 && <div style={{ color: "#5a5a70", textAlign: "center", padding: "24px" }}>No drill-through pages detected</div>}
        </div>}

        {outputView === "report" && <pre style={s.code}>{(() => {
          const lines = [`MIGRATION REPORT — ${new Date().toLocaleString()}`, "═".repeat(60), ""];
          conversions.forEach(c => {
            lines.push(`━━ ${c.sourceFile} (${c.sourceType}${c.sourceClassification ? " / " + c.sourceClassification : ""}) ━━`);
            lines.push(`Confidence: ${c.confidence}%`);
            c.mappings.forEach(m => {
              const icon = m.status === "Converted" ? "✓" : m.status === "Manual" ? "✎" : "⚠";
              lines.push(`  ${icon} [${m.category || "?"}] ${m.source}`);
              lines.push(`    → ${m.target}`);
            });
            lines.push("");
          });
          return lines.join("\n");
        })()}</pre>}
      </div>
    </div>;
  };

  // ═══════════════════════════════════════════════════════════════
  // Export Tab
  // ═══════════════════════════════════════════════════════════════
  const ExportTab = () => {
    if (!response) return <div style={{ ...s.card, textAlign: "center", padding: "40px", color: "#5a5a70" }}>Nothing to export</div>;
    const exports = [
      { icon: "★", label: "RDL Report Bundle (ZIP)", desc: "All .rdl files organized by type — open in Report Builder, publish to Report Server", primary: true,
        action: () => { setRdlGenerating(true); api.generateRdlBundle(files).finally(() => setRdlGenerating(false)); } },
      { icon: "⬧", label: "DAX Script", desc: "All measures, calculated columns, parameters, format strings", action: () => api.exportDAX(conversions) },
      { icon: "⬧", label: "Power Query M", desc: "M expressions, connection strings, MATCH/COMBINE transforms", action: () => api.exportMQuery(conversions) },
      { icon: "⬧", label: "Migration Report", desc: "Full line-by-line mapping with categories and confidence", action: () => api.exportReport(response) },
      { icon: "⬧", label: "Full JSON Export", desc: "Complete parsed data, conversions, features, and all definitions", action: () => api.downloadJSON(response, "migration_full_export.json") },
    ];
    return <div>
      <div style={s.card}>
        <div style={s.cardTitle}>↓ Export Migration Artifacts</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
          {exports.map((e, i) => <button key={i} style={{ background: e.primary ? "linear-gradient(135deg,#059669,#10b981)" : "#0a0b14", border: `1px solid ${e.primary ? "#10b981" : "#1a1a30"}`, borderRadius: "8px", padding: e.primary ? "18px" : "14px", cursor: "pointer", textAlign: "left", fontFamily: "inherit", transition: "all 0.15s", gridColumn: e.primary ? "1 / -1" : undefined }}
            onClick={e.action}
            onMouseEnter={ev => { ev.currentTarget.style.borderColor = "#4f46e5"; ev.currentTarget.style.background = "#141428"; }}
            onMouseLeave={ev => { ev.currentTarget.style.borderColor = "#1a1a30"; ev.currentTarget.style.background = "#0a0b14"; }}>
            <div style={{ fontSize: "12px", fontWeight: "800", color: "#fff", marginBottom: "3px" }}>{e.icon} {e.label}</div>
            <div style={{ fontSize: "10px", color: "#5a5a70" }}>{e.desc}</div>
          </button>)}
        </div>
      </div>
    </div>;
  };

  // ═══════════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════════
  return <div style={s.root}>
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800;900&display=swap');
      * { box-sizing: border-box; }
      ::-webkit-scrollbar { width: 5px; }
      ::-webkit-scrollbar-track { background: #0e0f18; }
      ::-webkit-scrollbar-thumb { background: #252540; border-radius: 3px; }
      button:hover { opacity: 0.92; }
      button:active { transform: scale(0.98); }
    `}</style>

    <div style={s.header}>
      <div style={s.logoBox}>
        <div style={s.logoMark}>WF</div>
        <div>
          <div style={s.title}>WebFocus → Power BI</div>
          <div style={s.subtitle}>Full-Stack Migration Engine v3.0</div>
        </div>
      </div>
      <nav style={s.nav}>
        {TABS.map(t => <button key={t.id} style={s.navBtn(tab === t.id)} onClick={() => setTab(t.id)}>
          <span>{t.icon}</span><span>{t.label}</span>
          {t.id === "mappings" && allMappings.length > 0 && <span style={{ background: "#7c3aed", color: "#fff", borderRadius: "99px", padding: "0 5px", fontSize: "9px", fontWeight: "900" }}>{allMappings.length}</span>}
        </button>)}
      </nav>
    </div>

    <div style={s.main}>
      {tab === "upload" && <UploadTab />}
      {tab === "analysis" && <AnalysisTab />}
      {tab === "mappings" && <MappingsTab />}
      {tab === "features" && <FeaturesTab />}
      {tab === "output" && <OutputTab />}
      {tab === "export" && <ExportTab />}
    </div>

    <div style={{ borderTop: "1px solid #1a1a30", padding: "8px 24px", display: "flex", justifyContent: "space-between", fontSize: "10px", color: "#3a3a4a" }}>
      <span>WebFocus 7/8 → Power BI · Full-Stack · Paginated · Self-Service · Active Reports</span>
      <span>{response ? `${summary.totalFiles} files · ${summary.totalMappings} mappings · ${summary.avgConfidence}%` : "Ready"}</span>
    </div>
  </div>;
}
