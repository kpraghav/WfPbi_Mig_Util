# WebFocus 7/8 → Power BI Full-Stack Migration Tool v3.0

Production-grade, end-to-end migration engine covering **all** WebFocus report types:
Standard Reports, Paginated Reports, Self-Service (InfoAssist), Active Reports,
Dashboards, ETL/HOLD chains, and Dialogue Manager procedures.

## Quick Start

### 1. Start Backend (Terminal 1)
```bash
cd backend
mvn clean package -DskipTests
mvn spring-boot:run
# API runs at http://localhost:8080
```

### 2. Start Frontend (Terminal 2)
```bash
cd frontend
npm install
npm run dev
# UI runs at http://localhost:3000
```

### 3. Test
Upload the sample files from `backend/samples/`:
- `retail_sales_analysis.fex` — Multi-report FEX with 7 requests
- `store_sales.mas` — Matching master file with 2 segments

## Architecture

```
Browser (localhost:3000)               Java Backend (localhost:8080)
┌──────────────────────┐              ┌──────────────────────────────┐
│  React UI            │   POST       │  Spring Boot REST API        │
│  Upload → Analyze    │──/api/───────│  MigrationController         │
│  Mappings → Export   │  migration/  │         │                    │
└──────────────────────┘  analyze     │  ┌──────▼──────────┐        │
         ▲                            │  │ MigrationService │        │
         │  JSON response             │  └──────┬──────────┘        │
         └────────────────────────────│  ┌──────▼──────────┐        │
                                      │  │   FexParser      │        │
                                      │  │   MasterParser   │        │
                                      │  └──────┬──────────┘        │
                                      │  ┌──────▼──────────┐        │
                                      │  │ PowerBIConverter │        │
                                      │  │ ExpressionConv.  │        │
                                      │  └─────────────────┘        │
                                      └──────────────────────────────┘
```

## Complete Feature Coverage

### Report Types Detected & Migrated

| WebFocus Type | Detection Method | Power BI Target |
|---|---|---|
| Standard TABLE/GRAPH | TABLE FILE / GRAPH FILE | Interactive Report |
| Paginated Report | PAGE-BREAK, HEADING/FOOTING, SET LINES, RECAP, TABPAGENO | PBI Paginated Report (RDL) |
| Self-Service (InfoAssist) | IBIF_EX header, INFOASSIST markers | PBI Interactive Report + Slicers |
| Active Report | ARVERSION, HOLDLIST, AHTML/DHTML | PBI Report + Bookmarks + Slicers |
| Dashboard | -HTMLFORM, COMPOUND LAYOUT, HTML composites | PBI Dashboard with pinned tiles |
| ETL Procedure | Multiple HOLD/PCHOLD in chain | PBI Dataflow |
| Drill-Down Report | FOCEXEC href references | PBI Drill-through pages |

### Paginated Report Features

| WebFocus Construct | Power BI Paginated (RDL) Target |
|---|---|
| PAGE-BREAK on BY field | Group with PageBreakAtStart |
| HEADING / SUBHEAD | Report Header / Group Header (repeat on new page) |
| FOOTING / SUBFOOT | Report Footer / Group Footer |
| TABPAGENO | =Globals!PageNumber |
| TABLASTPAGE | =Globals!TotalPages |
| TOD / D | =Now() |
| SET LINES n | Page height calculation |
| SUBTOTAL | Group footer with SUM expressions |
| COLUMN-TOTAL | Grand total row |
| RECAP / RECOMPUTE | DAX measures at group break level |

### Self-Service Features

| WebFocus Feature | Power BI Equivalent |
|---|---|
| Interactive filtering | Slicers + Visual-level filters |
| Interactive sorting | Column sort enabled |
| Drill-down | Drill-through pages |
| Export to Excel/PDF | Export menu enabled |
| Pivot | Matrix visual |
| Report Painter saved filters | Bookmarks |

### Data Operation Coverage

| WebFocus | Power BI | Status |
|---|---|---|
| DEFINE FILE ... END | Calculated Columns | Auto-converted |
| COMPUTE | DAX Measures | Auto-converted |
| RECAP / RECOMPUTE | DAX Measures (context-aware) | Needs Review |
| JOIN ... TO | Model Relationships | Auto-converted |
| MATCH FILE | Power Query Table.NestedJoin | Needs Review |
| COMBINE FILE | Power Query Table.Combine | Needs Review |
| HOLD / PCHOLD / SAVE | Dataflow steps | Mapped |
| BY (grouping) | Group By / Axis | Auto-converted |
| ACROSS (cross-tab) | Matrix columns | Auto-converted |
| WITHIN | Nested grouping | Mapped |
| WHERE / IF (filters) | DAX CALCULATE + FILTER | Auto-converted |
| ACCEPT / PROMPT | PBI Parameters / Slicers | Auto-converted |
| -SET &variable | PBI Parameters | Auto-converted |
| SET STYLE WHEN | Conditional Formatting rules | Auto-converted |
| GRID=ON | Table grid styling | Detected |
| FOCEXEC href | Drill-through pages | Mapped |
| -RUN chain | Power Automate flow | Manual |
| -IF/-GOTO/-REPEAT | Manual logic | Manual |

### Expression Conversion (100+ Functions)

**High Confidence** (auto-converted):
IF/THEN/ELSE, EQ/NE/GT/LT/GE/LE, AND/OR/NOT, SUBSTR→MID, UPCASE→UPPER,
LOCASE→LOWER, TRIM, CTRAN→SUBSTITUTE, ARGLEN→LEN, POSIT→FIND,
ABS, INT, ROUND, MOD, SQRT, LOG, EXP, POWER, SIGN, CEILING, FLOOR,
TODAY, concatenation (|→&), IS MISSING→ISBLANK, CONTAINS→CONTAINSSTRING,
BETWEEN, FTOA→FORMAT, ATODBL→VALUE

**Medium Confidence** (may need format mask review):
EDIT→FORMAT, DATEDIF→DATEDIFF, DATEFMT→FORMAT, CHGDAT→FORMAT,
HADD→EDATE, HDIFF→DATEDIFF, HDATE→DATE, HTIME→TIME

**Low Confidence** (manual review required):
DECODE→SWITCH, DATECVT→FORMAT, AYMD→EDATE, HCNVRT, HYYMD, HMASK,
LOOKUP→LOOKUPVALUE, MAINTAIN (N/A in DAX)

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/migration/analyze` | Upload files, full pipeline analysis |
| POST | `/api/migration/export/dax` | Download DAX script |
| POST | `/api/migration/export/m` | Download Power Query M script |
| POST | `/api/migration/export/rdl` | Download Paginated Report definition |
| POST | `/api/migration/export/report` | Download full migration report |
| GET | `/api/migration/health` | Health check with feature list |

## Requirements

- **Backend**: Java 17+, Maven 3.8+
- **Frontend**: Node.js 18+, npm
- No database — stateless processing
- No AI/ML — pure rule-based deterministic conversion
