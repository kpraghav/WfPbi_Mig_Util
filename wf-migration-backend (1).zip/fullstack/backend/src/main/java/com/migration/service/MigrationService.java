package com.migration.service;

import com.migration.converter.PowerBIConverter;
import com.migration.model.*;
import com.migration.model.ConversionResult.*;
import com.migration.model.MigrationResponse.*;
import com.migration.parser.*;
import org.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MigrationService {
    private static final Logger log = LoggerFactory.getLogger(MigrationService.class);

    private final FexParser fexParser;
    private final MasterFileParser masterParser;
    private final PowerBIConverter converter;

    public MigrationService(FexParser fexParser, MasterFileParser masterParser, PowerBIConverter converter) {
        this.fexParser = fexParser; this.masterParser = masterParser; this.converter = converter;
    }

    /**
     * Convert a single parsed FEX file — used by RDL generator.
     */
    public ConversionResult convertSingleFex(ParsedFexFile fex) {
        return converter.convertFexFile(fex);
    }

    public MigrationResponse processMigration(List<MultipartFile> files) {
        MigrationResponse response = new MigrationResponse();
        List<Object> parsed = new ArrayList<>();
        List<ConversionResult> conversions = new ArrayList<>();

        for (MultipartFile file : files) {
            try {
                String content = new String(file.getBytes(), StandardCharsets.UTF_8);
                String name = file.getOriginalFilename() != null ? file.getOriginalFilename() : "unknown";
                String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase();

                log.info("Processing: {} ({})", name, ext);
                if ("mas".equals(ext)) {
                    ParsedMasterFile p = masterParser.parse(content, name);
                    parsed.add(p);
                    conversions.add(converter.convertMasterFile(p));
                } else {
                    ParsedFexFile p = fexParser.parse(content, name);
                    parsed.add(p);
                    conversions.add(converter.convertFexFile(p));
                }
            } catch (IOException e) {
                response.getErrors().add("Failed to read: " + file.getOriginalFilename());
                log.error("IO error reading file", e);
            } catch (Exception e) {
                response.getErrors().add("Error processing " + file.getOriginalFilename() + ": " + e.getMessage());
                log.error("Processing error", e);
            }
        }

        response.getParsedFiles().addAll(parsed);
        response.getConversions().addAll(conversions);
        response.setSummary(buildSummary(parsed, conversions));
        response.setFeatureCoverage(buildFeatureCoverage(parsed, conversions));
        response.setStatus(response.getErrors().isEmpty() ? "success" : "partial");
        return response;
    }

    // ═══════════════════════════════════════════════════════════════
    // Export generators
    // ═══════════════════════════════════════════════════════════════
    public String generateDAXScript(List<ConversionResult> conversions) {
        StringBuilder sb = new StringBuilder();
        sb.append("// ═══════════════════════════════════════════════\n");
        sb.append("// Power BI DAX Script - WebFocus Migration\n");
        sb.append("// Generated: ").append(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)).append("\n");
        sb.append("// ═══════════════════════════════════════════════\n\n");

        for (ConversionResult c : conversions) {
            sb.append("// ── ").append(c.getSourceFile()).append(" (").append(c.getSourceType());
            if (c.getSourceClassification() != null) sb.append(" / ").append(c.getSourceClassification());
            sb.append(") ──\n\n");

            for (TableDef t : c.getPowerBI().getTables()) {
                sb.append("// Table: ").append(t.getName()).append("\n");
                for (ColumnDef col : t.getColumns())
                    sb.append("//   ").append(col.getName()).append(" (").append(col.getDataType()).append(")")
                      .append(col.getDescription().isEmpty() ? "" : " - " + col.getDescription()).append("\n");
                sb.append("\n");
            }
            for (CalculatedColumn cc : c.getPowerBI().getCalculatedColumns()) {
                sb.append("// Source: ").append(cc.getSource()).append("\n");
                sb.append(cc.getName()).append(" = ").append(cc.getExpression()).append("\n\n");
            }
            for (Measure m : c.getPowerBI().getMeasures()) {
                sb.append("// Source: ").append(m.getSource()).append("\n");
                sb.append(m.getName()).append(" = ").append(m.getExpression());
                if (m.getFormatString() != null) sb.append("\n// Format: ").append(m.getFormatString());
                sb.append("\n\n");
            }
            // Parameters
            for (ParameterDef p : c.getPowerBI().getParameters()) {
                sb.append("// Parameter: ").append(p.getName()).append(" (").append(p.getDataType()).append(")");
                if (p.getDefaultValue() != null) sb.append(" Default: ").append(p.getDefaultValue());
                sb.append("\n// Source: ").append(p.getSource()).append("\n\n");
            }
            // Conditional formats
            for (ConditionalFormat cf : c.getPowerBI().getConditionalFormats()) {
                sb.append("// Conditional Format: ").append(cf.getSource());
                if (cf.getCondition() != null) sb.append(" WHEN ").append(cf.getCondition());
                if (cf.getBackgroundColor() != null) sb.append(" BG=").append(cf.getBackgroundColor());
                sb.append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public String generateMQueryScript(List<ConversionResult> conversions) {
        StringBuilder sb = new StringBuilder();
        sb.append("// Power Query M - WebFocus Migration\n// Generated: ")
          .append(LocalDateTime.now()).append("\n\n");
        for (ConversionResult c : conversions) {
            for (MQuery q : c.getPowerBI().getQueries()) {
                sb.append("// ").append(q.getName()).append(" | Source: ").append(q.getSource()).append("\n");
                sb.append(q.getExpression()).append("\n\n");
            }
        }
        return sb.toString();
    }

    public String generateRDLSummary(List<ConversionResult> conversions) {
        StringBuilder sb = new StringBuilder();
        sb.append("PAGINATED REPORT DEFINITIONS (RDL Summary)\n").append("═".repeat(50)).append("\n\n");
        for (ConversionResult c : conversions) {
            if (c.getPaginatedReport() == null) continue;
            PaginatedReportDef pr = c.getPaginatedReport();
            sb.append("Report: ").append(pr.getReportName()).append("\n");
            sb.append("Page: ").append(pr.getPageSetup().getPageWidth()).append("\" x ").append(pr.getPageSetup().getPageHeight()).append("\"\n");
            if (pr.getHeader() != null) {
                sb.append("Header: ").append(String.join(" | ", pr.getHeader().getTextLines())).append("\n");
            }
            if (pr.getFooter() != null) {
                sb.append("Footer: ").append(String.join(" | ", pr.getFooter().getTextLines()));
                if (pr.getFooter().isHasPageNumber()) sb.append(" [Page#]");
                if (pr.getFooter().isHasTotalPages()) sb.append(" [TotalPages]");
                if (pr.getFooter().isHasRunDate()) sb.append(" [RunDate]");
                sb.append("\n");
            }
            sb.append("Parameters: ").append(pr.getParameters().size()).append("\n");
            for (ReportParameter rp : pr.getParameters()) {
                sb.append("  @").append(rp.getName()).append(" (").append(rp.getDataType()).append(")");
                if (rp.getDefaultValue() != null) sb.append(" = ").append(rp.getDefaultValue());
                sb.append("\n");
            }
            sb.append("Groups: ").append(pr.getGroups().size()).append("\n");
            for (GroupDefinition gd : pr.getGroups()) {
                sb.append("  ").append(gd.getFieldName());
                if (gd.isPageBreakBefore()) sb.append(" [PAGE-BREAK]");
                if (gd.isHasFooter()) sb.append(" [subtotals]");
                sb.append("\n");
            }
            sb.append("Body Items: ").append(pr.getBodyItems().size()).append("\n");
            for (ReportBody rb : pr.getBodyItems()) {
                sb.append("  ").append(rb.getType()).append(": ").append(rb.getName()).append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public String generateReport(List<Object> parsed, List<ConversionResult> conversions) {
        StringBuilder sb = new StringBuilder();
        sb.append("WEBFOCUS → POWER BI MIGRATION REPORT\n").append("═".repeat(60)).append("\n");
        sb.append("Generated: ").append(LocalDateTime.now()).append("\n");
        sb.append("Files: ").append(parsed.size()).append("\n\n");

        for (ConversionResult c : conversions) {
            sb.append("━━ ").append(c.getSourceFile()).append(" (").append(c.getSourceType());
            if (c.getSourceClassification() != null) sb.append(" / ").append(c.getSourceClassification());
            sb.append(") ━━\nConfidence: ").append(c.getConfidence()).append("%\n");
            for (Mapping m : c.getMappings()) {
                String icon = switch (m.getStatus()) { case "Converted" -> "✓"; case "Needs Review" -> "⚠"; case "Manual" -> "✎"; default -> "✕"; };
                sb.append("  ").append(icon).append(" [").append(m.getCategory() != null ? m.getCategory() : "?").append("] ").append(m.getSource()).append("\n");
                sb.append("    → ").append(m.getTarget()).append("\n");
            }
            if (!c.getIssues().isEmpty()) {
                sb.append("  Issues:\n");
                for (Issue iss : c.getIssues()) sb.append("    ⚠ ").append(iss.getMessage()).append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════
    private MigrationSummary buildSummary(List<Object> parsed, List<ConversionResult> conversions) {
        MigrationSummary s = new MigrationSummary();
        s.setTotalFiles(parsed.size());
        int total = 0, conv = 0, review = 0, unsup = 0, conf = 0;
        Map<String, Integer> byCat = new LinkedHashMap<>(), byCls = new LinkedHashMap<>();
        for (ConversionResult c : conversions) {
            total += c.getMappings().size();
            for (Mapping m : c.getMappings()) {
                switch (m.getStatus()) { case "Converted" -> conv++; case "Needs Review" -> review++; default -> unsup++; }
                if (m.getCategory() != null) byCat.merge(m.getCategory(), 1, Integer::sum);
            }
            conf += c.getConfidence();
            if (c.getSourceClassification() != null) byCls.merge(c.getSourceClassification(), 1, Integer::sum);
        }
        s.setTotalMappings(total); s.setConvertedMappings(conv); s.setReviewMappings(review);
        s.setUnsupportedMappings(unsup);
        s.setAvgConfidence(conversions.isEmpty() ? 0 : Math.round((float) conf / conversions.size()));
        s.getByCategory().putAll(byCat); s.getByClassification().putAll(byCls);
        return s;
    }

    private FeatureCoverage buildFeatureCoverage(List<Object> parsed, List<ConversionResult> conversions) {
        FeatureCoverage fc = new FeatureCoverage();
        for (ConversionResult c : conversions) {
            if (c.getPaginatedReport() != null) fc.setPaginatedReports(true);
            if (c.getSelfServiceMapping() != null) fc.setSelfService(true);
            if (c.getActiveReportMapping() != null) fc.setActiveReports(true);
            if (c.getDashboardMapping() != null) fc.setDashboards(true);
            if (c.getDataflow() != null) fc.setHoldChains(true);
            if (!c.getPowerBI().getConditionalFormats().isEmpty()) fc.setConditionalFormatting(true);
            if (!c.getPowerBI().getParameters().isEmpty()) fc.setParameters(true);
            if (!c.getPowerBI().getDrillThroughPages().isEmpty()) fc.setDrillDown(true);
            for (VisualConfig vc : c.getPowerBI().getVisualConfigs()) {
                if ("Matrix".equals(vc.getType())) fc.setCrossTab(true);
            }
        }
        for (Object p : parsed) {
            if (p instanceof ParsedFexFile fex && !fex.getDialogueManagerCommands().isEmpty()) fc.setDialogueManager(true);
        }
        return fc;
    }
}
