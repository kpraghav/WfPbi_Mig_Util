package com.migration.parser;

import com.migration.model.ParsedMasterFile;
import com.migration.model.ParsedMasterFile.*;
import org.springframework.stereotype.Service;
import java.util.regex.*;

@Service
public class MasterFileParser {

    public ParsedMasterFile parse(String content, String fileName) {
        ParsedMasterFile result = new ParsedMasterFile();
        result.setFileName(fileName);
        String[] rawLines = content.split("\\n");
        result.setRawLineCount(rawLines.length);
        Segment currentSegment = null;

        for (int i = 0; i < rawLines.length; i++) {
            String line = rawLines[i].trim();
            String upper = line.toUpperCase();
            if (line.isEmpty() || upper.startsWith("$")) continue;

            // FILENAME / SUFFIX / CONNECTION
            if (upper.startsWith("FILENAME") || (upper.startsWith("FILE") && upper.contains("="))) {
                Matcher m = Pattern.compile("(?:FILENAME|FILE)\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (m.find()) result.setAccessFile(m.group(1));
                Matcher sm = Pattern.compile("SUFFIX\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (sm.find()) result.setSuffix(sm.group(1));
                Matcher cm = Pattern.compile("CONNECTION\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (cm.find()) result.setConnection(cm.group(1));
            }

            // SEGNAME / SEGMENT
            if (upper.startsWith("SEGNAME") || upper.startsWith("SEGMENT")) {
                Matcher m = Pattern.compile("(?:SEGNAME|SEGMENT)\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (m.find()) {
                    currentSegment = new Segment();
                    currentSegment.setName(m.group(1));
                    Matcher pm = Pattern.compile("PARENT\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                    if (pm.find()) currentSegment.setParent(pm.group(1));
                    Matcher stm = Pattern.compile("SEGTYPE\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                    if (stm.find()) currentSegment.setSegType(stm.group(1));
                    Matcher tm = Pattern.compile("TABLENAME\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                    if (tm.find()) currentSegment.setTableName(tm.group(1));
                    if (upper.contains("CRFILE")) {
                        currentSegment.setCrossRef(true);
                        Matcher crm = Pattern.compile("CRFILE\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                        if (crm.find()) currentSegment.setCrossRefFile(crm.group(1));
                    }
                    result.getSegments().add(currentSegment);
                }
            }

            // FIELDNAME / FIELD
            if (upper.startsWith("FIELDNAME") || (upper.startsWith("FIELD") && upper.contains("="))) {
                MasterField field = parseFieldLine(line, i + 1, currentSegment);
                if (field != null) {
                    result.getFields().add(field);
                    if (currentSegment != null) currentSegment.getFields().add(field);
                }
            }

            // INDEX
            if (upper.startsWith("INDEX") || upper.contains("INDEX=")) {
                IndexSpec idx = new IndexSpec();
                idx.setLine(i + 1); idx.setText(line);
                Matcher im = Pattern.compile("INDEX\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (im.find()) idx.setFieldName(im.group(1));
                idx.setPrimary(upper.contains("PRIMARY") || upper.contains("UNIQUE"));
                result.getIndices().add(idx);
            }

            // ALIAS at segment level
            if (upper.startsWith("ALIAS")) {
                Matcher m = Pattern.compile("ALIAS\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (m.find()) { AliasSpec a = new AliasSpec(); a.setName(m.group(1)); a.setLine(i + 1); result.getAliases().add(a); }
            }

            // DEFINE in master
            if (upper.startsWith("DEFINE") && !upper.startsWith("DEFINE FILE")) {
                Matcher dm = Pattern.compile("DEFINE\\s+(\\w+)(?:/(\\w+))?\\s*=\\s*(.+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (dm.find()) {
                    DefineInMaster d = new DefineInMaster();
                    d.setField(dm.group(1)); d.setFormat(dm.group(2)); d.setExpression(dm.group(3).replaceAll(";$", "").trim());
                    result.getDefines().add(d);
                }
            }

            // DBA (Database Access)
            if (upper.contains("DATABASE") || upper.contains("SCHEMA") || upper.contains("CATALOG") || upper.contains("TABLESPACE")) {
                if (result.getDbaConfig() == null) result.setDbaConfig(new DBAConfig());
                DBAConfig dba = result.getDbaConfig();
                Matcher db = Pattern.compile("DATABASE\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (db.find()) dba.setDbType(db.group(1));
                Matcher sc = Pattern.compile("SCHEMA\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (sc.find()) dba.setSchema(sc.group(1));
                Matcher ca = Pattern.compile("CATALOG\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (ca.find()) dba.setCatalog(ca.group(1));
            }
        }
        return result;
    }

    private MasterField parseFieldLine(String line, int lineNum, Segment segment) {
        Matcher nm = Pattern.compile("(?:FIELDNAME|FIELD)\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!nm.find()) return null;
        MasterField f = new MasterField();
        f.setName(nm.group(1)); f.setLine(lineNum);
        f.setSegment(segment != null ? segment.getName() : null);

        Matcher am = Pattern.compile("ALIAS\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (am.find()) f.setAlias(am.group(1));
        Matcher fm = Pattern.compile("FORMAT\\s*=\\s*(\\w+\\.?\\w*)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!fm.find()) fm = Pattern.compile("\\b([AIPDHYM]\\d+(?:\\.\\d+)?)\\b").matcher(line);
        if (fm.find()) {
            f.setFormat(fm.group(1));
            Matcher tm = Pattern.compile("^([AIPDHYM])(\\d+)(?:\\.(\\d+))?").matcher(f.getFormat());
            if (tm.find()) {
                f.setLength(Integer.parseInt(tm.group(2)));
                if (tm.group(3) != null) f.setDecimals(Integer.parseInt(tm.group(3)));
                f.setDataType(switch (tm.group(1)) {
                    case "A" -> "ALPHANUMERIC"; case "I" -> "INTEGER"; case "P" -> "PACKED";
                    case "D" -> "DOUBLE"; case "H" -> "DATETIME"; case "Y" -> "DATE"; default -> "ALPHANUMERIC";
                });
            }
        }
        Matcher ti = Pattern.compile("TITLE\\s*=\\s*[\"']?([^\"',]+)[\"']?", Pattern.CASE_INSENSITIVE).matcher(line);
        if (ti.find()) f.setTitle(ti.group(1).trim());
        Matcher de = Pattern.compile("DESCRIPTION\\s*=\\s*[\"']?([^\"',]+)[\"']?", Pattern.CASE_INSENSITIVE).matcher(line);
        if (de.find()) f.setDescription(de.group(1).trim());
        Matcher mi = Pattern.compile("MISSING\\s*=\\s*(ON|OFF)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (mi.find()) f.setMissing(mi.group(1).toUpperCase());
        Matcher ac = Pattern.compile("ACTUAL\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (ac.find()) f.setActualName(ac.group(1));
        if (line.toUpperCase().contains("VIRTUAL")) f.setVirtual(true);
        Matcher us = Pattern.compile("USAGE\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (us.find()) f.setUsage(us.group(1));

        return f;
    }
}
