package com.migration.converter;

import org.springframework.stereotype.Component;
import java.util.*;
import java.util.regex.*;

/**
 * Converts WebFocus expressions, functions, conditions, and operators to DAX / M equivalents.
 * Coverage: 100+ WebFocus functions across String, Date, Math, Conversion, Conditional categories.
 */
@Component
public class ExpressionConverter {

    public static class ConversionOutcome {
        private final String dax;
        private final double confidence;
        private final List<String> issues;
        public ConversionOutcome(String dax, double confidence, List<String> issues) {
            this.dax = dax; this.confidence = confidence; this.issues = issues;
        }
        public String getDax() { return dax; }
        public double getConfidence() { return confidence; }
        public List<String> getIssues() { return issues; }
    }

    // ─── Aggregation Mappings ────────────────────────────────────
    private static final Map<String, String> AGG_DAX = Map.ofEntries(
        Map.entry("SUM", "SUM"), Map.entry("COUNT", "COUNTA"), Map.entry("CNT", "COUNTA"),
        Map.entry("AVG", "AVERAGE"), Map.entry("MIN", "MIN"), Map.entry("MAX", "MAX"),
        Map.entry("PCT", "DIVIDE"), Map.entry("FIRST", "FIRSTNONBLANK"),
        Map.entry("LAST", "LASTNONBLANK"), Map.entry("MEDIAN", "MEDIAN"),
        Map.entry("STDEV", "STDEV.S")
    );

    private static final Map<String, String> AGG_M = Map.ofEntries(
        Map.entry("SUM", "List.Sum"), Map.entry("COUNT", "List.Count"), Map.entry("CNT", "List.Count"),
        Map.entry("AVG", "List.Average"), Map.entry("MIN", "List.Min"), Map.entry("MAX", "List.Max"),
        Map.entry("MEDIAN", "List.Median"), Map.entry("STDEV", "List.StandardDeviation")
    );

    // ─── Function Mappings (regex pattern → replacement) ─────────
    // Ordered: more specific patterns first
    private static final LinkedHashMap<String, String> FUNC_HIGH_CONF = new LinkedHashMap<>() {{
        // String functions
        put("SUBSTR\\s*\\(", "MID(");
        put("TRIM\\s*\\(", "TRIM(");
        put("LTRIM\\s*\\(", "TRIM("); // DAX TRIM handles both
        put("RTRIM\\s*\\(", "TRIM(");
        put("UPCASE\\s*\\(", "UPPER(");
        put("LOCASE\\s*\\(", "LOWER(");
        put("CTRAN\\s*\\(", "SUBSTITUTE(");
        put("ARGLEN\\s*\\(", "LEN(");
        put("POSIT\\s*\\(", "FIND(");
        put("REVERSE\\s*\\(", "/* REVERSE - no DAX equivalent */ REVERSE(");
        put("LJUST\\s*\\(", "/* LJUST */ TRIM(");
        put("RJUST\\s*\\(", "/* RJUST */ TRIM(");
        put("SQUEEZE\\s*\\(", "TRIM(");
        put("OADDTOK\\s*\\(", "/* OADDTOK */ COMBINEVALUES(");
        put("PARONE\\s*\\(", "/* PARONE - extract token */ MID(");
        put("PATTERN\\s*\\(", "/* PATTERN */ CONTAINSSTRING(");

        // Math functions
        put("\\bABS\\s*\\(", "ABS(");
        put("\\bINT\\s*\\(", "INT(");
        put("\\bROUND\\s*\\(", "ROUND(");
        put("\\bMOD\\s*\\(", "MOD(");
        put("\\bSQRT\\s*\\(", "SQRT(");
        put("\\bLOG\\s*\\(", "LOG(");
        put("\\bEXP\\s*\\(", "EXP(");
        put("\\bTRUNCATE\\s*\\(", "TRUNC(");
        put("\\bCEILING\\s*\\(", "CEILING(");
        put("\\bFLOOR\\s*\\(", "FLOOR(");
        put("\\bSIGN\\s*\\(", "SIGN(");
        put("\\bPOWER\\s*\\(", "POWER(");
        put("\\bRANDOM\\s*\\(", "RAND(");

        // Logical
        put("\\bMIN\\s*\\((?!.*FILE)", "MIN(");
        put("\\bMAX\\s*\\((?!.*FILE)", "MAX(");
        put("TODAY\\s*\\(\\s*\\)", "TODAY()");

        // Type conversion
        put("FTOA\\s*\\(", "FORMAT(");
        put("ATODBL\\s*\\(", "VALUE(");
        put("ITONUM\\s*\\(", "VALUE(");
        put("ATOS\\s*\\(", "FORMAT(");
    }};

    private static final LinkedHashMap<String, String> FUNC_MED_CONF = new LinkedHashMap<>() {{
        put("EDIT\\s*\\(", "FORMAT(");
        put("DATEDIF\\s*\\(", "DATEDIFF(");
        put("DATEFMT\\s*\\(", "FORMAT(");
        put("CHGDAT\\s*\\(", "FORMAT(");
        put("HDATE\\s*\\(", "DATE(");
        put("HTIME\\s*\\(", "TIME(");
        put("HADD\\s*\\(", "EDATE(");
        put("HDIFF\\s*\\(", "DATEDIFF(");
    }};

    private static final LinkedHashMap<String, String> FUNC_LOW_CONF = new LinkedHashMap<>() {{
        put("DECODE\\s*\\(", "SWITCH(");
        put("DATECVT\\s*\\(", "/* DATECVT - manual review */ FORMAT(");
        put("AYMD\\s*\\(", "/* AYMD - manual review */ EDATE(");
        put("HCNVRT\\s*\\(", "/* HCNVRT - manual review */ FORMAT(");
        put("HYYMD\\s*\\(", "/* HYYMD - manual review */ DATE(");
        put("HMASK\\s*\\(", "/* HMASK - manual review */ FORMAT(");
        put("HHMMSS\\s*\\(", "/* HHMMSS - manual review */ TIME(");
        put("CHKFMT\\s*\\(", "/* CHKFMT - manual review */ ISERROR(VALUE(");
        put("LOOKUP\\s*\\(", "/* LOOKUP → LOOKUPVALUE */ LOOKUPVALUE(");
        put("FIND\\s*\\(", "/* FIND → CALCULATE FILTER */ CALCULATE(MAXX(FILTER(");
        put("MAINTAIN\\s*\\(", "/* MAINTAIN - not applicable in DAX */");
    }};

    // ─── Main Expression Converter ───────────────────────────────
    public ConversionOutcome convertExpression(String expr) {
        String dax = expr;
        double confidence = 0.9;
        List<String> issues = new ArrayList<>();

        // 1. IF THEN ELSE (handle nested)
        dax = convertNestedIfThenElse(dax);

        // 2. High-confidence functions
        for (var entry : FUNC_HIGH_CONF.entrySet()) {
            if (Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).find()) {
                dax = Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).replaceAll(entry.getValue());
            }
        }

        // 3. Medium-confidence functions
        for (var entry : FUNC_MED_CONF.entrySet()) {
            if (Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).find()) {
                dax = Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).replaceAll(entry.getValue());
                confidence = Math.min(confidence, 0.7);
                issues.add(entry.getValue().replace("(", "") + " may need format mask adjustment");
            }
        }

        // 4. Low-confidence functions
        for (var entry : FUNC_LOW_CONF.entrySet()) {
            if (Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).find()) {
                dax = Pattern.compile(entry.getKey(), Pattern.CASE_INSENSITIVE).matcher(dax).replaceAll(entry.getValue());
                confidence = Math.min(confidence, 0.45);
                issues.add("Manual review required for: " + entry.getKey().replaceAll("\\\\[sb]\\*\\\\\\(", ""));
            }
        }

        // 5. Concatenation
        dax = dax.replaceAll("\\s*\\|\\s*", " & ");

        // 6. Amper variables → Power BI parameter refs
        dax = dax.replaceAll("&(\\w+)", "[@$1]");

        return new ConversionOutcome(dax, confidence, issues);
    }

    // Handle nested IF/THEN/ELSE by converting innermost first
    private String convertNestedIfThenElse(String expr) {
        String dax = expr;
        int maxIterations = 10;
        while (maxIterations-- > 0) {
            // Match innermost IF THEN ELSE (no nested IF inside)
            Pattern p = Pattern.compile(
                "IF\\s+([^I]*?|(?:(?!\\bIF\\b).)*?)\\s+THEN\\s+([^I]*?|(?:(?!\\bIF\\b).)*?)\\s+ELSE\\s+([^I]*?|(?:(?!\\bIF\\b).)*?)(?=\\s+ELSE|;|$)",
                Pattern.CASE_INSENSITIVE
            );
            Matcher m = p.matcher(dax);
            if (!m.find()) break;
            String cond = convertCondition(m.group(1).trim());
            String thenPart = m.group(2).trim();
            String elsePart = m.group(3).trim();
            dax = dax.substring(0, m.start()) + "IF(" + cond + ", " + thenPart + ", " + elsePart + ")" + dax.substring(m.end());
        }
        // Fallback: simple single-level
        dax = dax.replaceAll("(?i)IF\\s+(.+?)\\s+THEN\\s+(.+?)\\s+ELSE\\s+(.+?)(?:;|$)",
            "IF($1, $2, $3)");
        return dax;
    }

    public String convertCondition(String cond) {
        String r = cond;
        r = r.replaceAll("(?i)\\bEQ\\b", "==");
        r = r.replaceAll("(?i)\\bNE\\b", "<>");
        r = r.replaceAll("(?i)\\bGT\\b", ">");
        r = r.replaceAll("(?i)\\bLT\\b", "<");
        r = r.replaceAll("(?i)\\bGE\\b", ">=");
        r = r.replaceAll("(?i)\\bLE\\b", "<=");
        r = r.replaceAll("(?i)\\bAND\\b", "&&");
        r = r.replaceAll("(?i)\\bOR\\b", "||");
        r = r.replaceAll("(?i)\\bNOT\\b", "NOT");
        r = r.replaceAll("(?i)\\bIS\\s+MISSING\\b", "ISBLANK");
        r = r.replaceAll("(?i)\\bIS\\s+NOT\\s+MISSING\\b", "NOT ISBLANK");
        r = r.replaceAll("(?i)\\bCONTAINS\\b", "CONTAINSSTRING");
        r = r.replaceAll("(?i)\\bLIKE\\s+'(.+?)'", "CONTAINSSTRING(, \"$1\")");
        r = r.replaceAll("(?i)\\bBETWEEN\\s+(.+?)\\s+AND\\s+(.+)", ">= $1 && <= $2");
        r = r.replaceAll("(?i)\\bIN\\s*\\(", "IN {");
        return r.trim();
    }

    public String convertFilter(String filterExpr, String tableName) {
        String dax = filterExpr.replaceAll("(?i)^(WHERE|IF)\\s+", "");
        dax = convertCondition(dax);
        dax = dax.replaceAll("&(\\w+)", "[@$1]");
        return "CALCULATE( [Measure], FILTER(" + tableName + ", " + dax + ") )";
    }

    public String mapAggregation(String wfAgg) { return AGG_DAX.getOrDefault(wfAgg.toUpperCase(), "SUM"); }
    public String mapAggregationToM(String wfAgg) { return AGG_M.getOrDefault(wfAgg.toUpperCase(), "List.Sum"); }

    public String mapDataType(String wfFormat, String wfType) {
        if (wfType != null) return switch (wfType) {
            case "ALPHANUMERIC" -> "String";
            case "INTEGER" -> "Int64";
            case "PACKED" -> "Decimal";
            case "DOUBLE" -> "Double";
            case "DATE", "DATETIME" -> "DateTime";
            default -> "String";
        };
        if (wfFormat != null) {
            if (wfFormat.startsWith("A")) return "String";
            if (wfFormat.startsWith("I")) return "Int64";
            if (wfFormat.matches("(?i).*(?:YMD|MDY|DMY|YYMD|HIS).*")) return "DateTime";
            if (wfFormat.startsWith("H") || wfFormat.startsWith("Y")) return "DateTime";
            if (wfFormat.startsWith("D") || wfFormat.startsWith("P")) return "Double";
        }
        return "String";
    }

    public String mapGraphType(String wfType, List<String> rawLines) {
        if (wfType != null) return switch (wfType.toUpperCase()) {
            case "PIE" -> "Pie Chart";
            case "BAR", "VBAR" -> "Clustered Bar Chart";
            case "HBAR" -> "Clustered Bar Chart (Horizontal)";
            case "LINE" -> "Line Chart";
            case "AREA" -> "Area Chart";
            case "SCATTER" -> "Scatter Chart";
            case "BUBBLE" -> "Scatter Chart";
            case "GAUGE" -> "Gauge";
            case "FUNNEL" -> "Funnel";
            case "TREEMAP" -> "Treemap";
            default -> "Clustered Column Chart";
        };
        if (rawLines != null) {
            String combined = String.join(" ", rawLines).toUpperCase();
            if (combined.contains("PIE")) return "Pie Chart";
            if (combined.contains("LINE")) return "Line Chart";
            if (combined.contains("HBAR")) return "Clustered Bar Chart (Horizontal)";
            if (combined.contains("BAR") || combined.contains("VBAR")) return "Clustered Bar Chart";
        }
        return "Clustered Column Chart";
    }

    // Convert WebFocus format mask to DAX format string
    public String convertFormatMask(String wfFormat) {
        if (wfFormat == null) return null;
        if (wfFormat.matches("D\\d+\\.\\d+")) {
            int decimals = Integer.parseInt(wfFormat.replaceAll("D\\d+\\.", ""));
            return "#,##0." + "0".repeat(decimals);
        }
        if (wfFormat.matches("I\\d+")) return "#,##0";
        if (wfFormat.startsWith("P")) return "#,##0.00";
        return null;
    }

    // Convert WebFocus color name to hex
    public String convertColor(String wfColor) {
        if (wfColor == null) return null;
        return switch (wfColor.toUpperCase()) {
            case "RED" -> "#FF0000"; case "GREEN" -> "#00FF00"; case "BLUE" -> "#0000FF";
            case "YELLOW" -> "#FFFF00"; case "WHITE" -> "#FFFFFF"; case "BLACK" -> "#000000";
            case "LIGHTGREEN" -> "#90EE90"; case "LIGHTBLUE" -> "#ADD8E6";
            case "LIGHTYELLOW" -> "#FFFFE0"; case "LIGHTGRAY", "LIGHTGREY" -> "#D3D3D3";
            case "ORANGE" -> "#FFA500"; case "PINK" -> "#FFC0CB"; case "PURPLE" -> "#800080";
            default -> wfColor;
        };
    }
}
