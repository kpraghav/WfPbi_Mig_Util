package com.migration.model;

import java.util.*;

/**
 * Comprehensive model for a parsed WebFocus FOCEXEC (.fex) file.
 * Covers: TABLE/GRAPH requests, DEFINE/COMPUTE, JOINs, MATCH/COMBINE,
 * Dialogue Manager commands, Self-Service (InfoAssist), Active Reports,
 * Paginated Report features, Conditional Styling, Parameters/Prompts,
 * HOLD chains, and all WebFocus 7/8 constructs.
 */
public class ParsedFexFile {
    private String fileName;
    private final String type = "fex";
    private int rawLineCount;
    private FileClassification classification = new FileClassification();

    // Core structures
    private List<TableRequest> requests = new ArrayList<>();
    private List<DefineField> defines = new ArrayList<>();
    private List<JoinSpec> joins = new ArrayList<>();
    private List<MatchSpec> matches = new ArrayList<>();

    // Dialogue Manager
    private List<Variable> variables = new ArrayList<>();
    private List<IncludeRef> includes = new ArrayList<>();
    private List<PromptSpec> prompts = new ArrayList<>();
    private List<DMCommand> dialogueManagerCommands = new ArrayList<>();
    private List<RunChain> runChains = new ArrayList<>();

    // Self-Service / InfoAssist metadata
    private SelfServiceMeta selfService;

    // Active Report config
    private ActiveReportConfig activeReportConfig;

    // Hold chain / ETL
    private List<HoldSpec> holds = new ArrayList<>();
    private List<String> comments = new ArrayList<>();
    private List<String> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();

    // Getters/Setters
    public String getFileName() { return fileName; }
    public void setFileName(String f) { this.fileName = f; }
    public String getType() { return type; }
    public int getRawLineCount() { return rawLineCount; }
    public void setRawLineCount(int n) { this.rawLineCount = n; }
    public FileClassification getClassification() { return classification; }
    public void setClassification(FileClassification c) { this.classification = c; }
    public List<TableRequest> getRequests() { return requests; }
    public List<DefineField> getDefines() { return defines; }
    public List<JoinSpec> getJoins() { return joins; }
    public List<MatchSpec> getMatches() { return matches; }
    public List<Variable> getVariables() { return variables; }
    public List<IncludeRef> getIncludes() { return includes; }
    public List<PromptSpec> getPrompts() { return prompts; }
    public List<DMCommand> getDialogueManagerCommands() { return dialogueManagerCommands; }
    public List<RunChain> getRunChains() { return runChains; }
    public SelfServiceMeta getSelfService() { return selfService; }
    public void setSelfService(SelfServiceMeta s) { this.selfService = s; }
    public ActiveReportConfig getActiveReportConfig() { return activeReportConfig; }
    public void setActiveReportConfig(ActiveReportConfig a) { this.activeReportConfig = a; }
    public List<HoldSpec> getHolds() { return holds; }
    public List<String> getComments() { return comments; }
    public List<String> getErrors() { return errors; }
    public List<String> getWarnings() { return warnings; }

    // ──────────────────────────────────────────────────────────────
    // File Classification — what type of WebFocus asset is this?
    // ──────────────────────────────────────────────────────────────
    public static class FileClassification {
        private boolean isPaginatedReport;
        private boolean isSelfServiceReport;    // InfoAssist / Report Painter
        private boolean isDashboard;             // HTML Composite
        private boolean isActiveReport;          // Active Technologies
        private boolean isEtlProcedure;          // HOLD chain / data prep
        private boolean isDrillDown;             // Drill-down report
        private boolean isParameterized;         // Uses ACCEPT/PROMPT
        private boolean isScheduled;             // Has scheduling metadata
        private boolean isSubroutine;            // Called by -RUN / -INCLUDE
        private boolean hasCrossTab;             // Uses ACROSS
        private boolean hasConditionalFormatting; // SET STYLE with WHEN
        private String sourceVersion;            // "7.7", "8.2", etc.
        private String outputType;               // HTML, PDF, EXCEL, ACTIVE, etc.

        // All getters/setters
        public boolean isPaginatedReport() { return isPaginatedReport; }
        public void setPaginatedReport(boolean v) { isPaginatedReport = v; }
        public boolean isSelfServiceReport() { return isSelfServiceReport; }
        public void setSelfServiceReport(boolean v) { isSelfServiceReport = v; }
        public boolean isDashboard() { return isDashboard; }
        public void setDashboard(boolean v) { isDashboard = v; }
        public boolean isActiveReport() { return isActiveReport; }
        public void setActiveReport(boolean v) { isActiveReport = v; }
        public boolean isEtlProcedure() { return isEtlProcedure; }
        public void setEtlProcedure(boolean v) { isEtlProcedure = v; }
        public boolean isDrillDown() { return isDrillDown; }
        public void setDrillDown(boolean v) { isDrillDown = v; }
        public boolean isParameterized() { return isParameterized; }
        public void setParameterized(boolean v) { isParameterized = v; }
        public boolean isScheduled() { return isScheduled; }
        public void setScheduled(boolean v) { isScheduled = v; }
        public boolean isSubroutine() { return isSubroutine; }
        public void setSubroutine(boolean v) { isSubroutine = v; }
        public boolean hasCrossTab() { return hasCrossTab; }
        public void setCrossTab(boolean v) { hasCrossTab = v; }
        public boolean hasConditionalFormatting() { return hasConditionalFormatting; }
        public void setConditionalFormatting(boolean v) { hasConditionalFormatting = v; }
        public String getSourceVersion() { return sourceVersion; }
        public void setSourceVersion(String v) { sourceVersion = v; }
        public String getOutputType() { return outputType; }
        public void setOutputType(String v) { outputType = v; }
    }

    // ──────────────────────────────────────────────────────────────
    // TABLE / GRAPH Request — the core report definition
    // ──────────────────────────────────────────────────────────────
    public static class TableRequest {
        private String type;          // TABLE, GRAPH
        private String file;
        private int line;
        private List<RequestField> fields = new ArrayList<>();
        private List<FilterSpec> filters = new ArrayList<>();
        private List<String> groupBy = new ArrayList<>();
        private List<String> sortBy = new ArrayList<>();
        private List<ComputeField> computes = new ArrayList<>();
        private List<RecapField> recaps = new ArrayList<>();        // RECAP/RECOMPUTE
        private List<String> headings = new ArrayList<>();
        private List<String> footings = new ArrayList<>();
        private List<String> subHeadings = new ArrayList<>();
        private List<String> subFootings = new ArrayList<>();

        // Pagination
        private PaginationConfig pagination = new PaginationConfig();

        // Cross-tab
        private List<String> acrossFields = new ArrayList<>();
        private String withinField;                                   // WITHIN

        // Output & Styling
        private List<String> onTableSet = new ArrayList<>();
        private String outputFormat;
        private List<StyleRule> styleRules = new ArrayList<>();
        private GridConfig gridConfig;

        // Graph specifics
        private GraphConfig graphConfig;

        // Active Report
        private boolean isActiveReport;
        private List<String> holdListFields = new ArrayList<>();

        // Drill-down
        private List<DrillDownSpec> drillDowns = new ArrayList<>();

        // Column totals / subtotals
        private boolean subTotals;
        private boolean columnTotal;
        private boolean rowTotal;
        private List<String> pageBreaks = new ArrayList<>();
        private List<String> raw = new ArrayList<>();

        // Getters/Setters — all fields
        public String getType() { return type; }
        public void setType(String t) { this.type = t; }
        public String getFile() { return file; }
        public void setFile(String f) { this.file = f; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public List<RequestField> getFields() { return fields; }
        public List<FilterSpec> getFilters() { return filters; }
        public List<String> getGroupBy() { return groupBy; }
        public List<String> getSortBy() { return sortBy; }
        public List<ComputeField> getComputes() { return computes; }
        public List<RecapField> getRecaps() { return recaps; }
        public List<String> getHeadings() { return headings; }
        public List<String> getFootings() { return footings; }
        public List<String> getSubHeadings() { return subHeadings; }
        public List<String> getSubFootings() { return subFootings; }
        public PaginationConfig getPagination() { return pagination; }
        public void setPagination(PaginationConfig p) { this.pagination = p; }
        public List<String> getAcrossFields() { return acrossFields; }
        public String getWithinField() { return withinField; }
        public void setWithinField(String w) { this.withinField = w; }
        public List<String> getOnTableSet() { return onTableSet; }
        public String getOutputFormat() { return outputFormat; }
        public void setOutputFormat(String f) { this.outputFormat = f; }
        public List<StyleRule> getStyleRules() { return styleRules; }
        public GridConfig getGridConfig() { return gridConfig; }
        public void setGridConfig(GridConfig g) { this.gridConfig = g; }
        public GraphConfig getGraphConfig() { return graphConfig; }
        public void setGraphConfig(GraphConfig g) { this.graphConfig = g; }
        public boolean isActiveReport() { return isActiveReport; }
        public void setActiveReport(boolean a) { this.isActiveReport = a; }
        public List<String> getHoldListFields() { return holdListFields; }
        public List<DrillDownSpec> getDrillDowns() { return drillDowns; }
        public boolean isSubTotals() { return subTotals; }
        public void setSubTotals(boolean s) { this.subTotals = s; }
        public boolean isColumnTotal() { return columnTotal; }
        public void setColumnTotal(boolean c) { this.columnTotal = c; }
        public boolean isRowTotal() { return rowTotal; }
        public void setRowTotal(boolean r) { this.rowTotal = r; }
        public List<String> getPageBreaks() { return pageBreaks; }
        public List<String> getRaw() { return raw; }
    }

    // ──────────────────────────────────────────────────────────────
    // Pagination Config — for paginated report conversion
    // ──────────────────────────────────────────────────────────────
    public static class PaginationConfig {
        private boolean hasPageBreaks;
        private List<String> pageBreakFields = new ArrayList<>();
        private int linesPerPage = 60;        // ON TABLE SET LINES
        private boolean noPage;               // NOPAGE
        private boolean noLead;               // NOLEAD
        private boolean repeatGroupHeaders = true;
        private boolean hasPageNumbering;     // <TABPAGENO>
        private boolean hasRunDate;           // <TOD>, <D>
        private boolean hasTotalPages;        // <TABLASTPAGE>
        private List<String> pageHeaderVars = new ArrayList<>();  // variables used in headings
        private List<String> pageFooterVars = new ArrayList<>();

        public boolean isHasPageBreaks() { return hasPageBreaks; }
        public void setHasPageBreaks(boolean h) { this.hasPageBreaks = h; }
        public List<String> getPageBreakFields() { return pageBreakFields; }
        public int getLinesPerPage() { return linesPerPage; }
        public void setLinesPerPage(int l) { this.linesPerPage = l; }
        public boolean isNoPage() { return noPage; }
        public void setNoPage(boolean n) { this.noPage = n; }
        public boolean isNoLead() { return noLead; }
        public void setNoLead(boolean n) { this.noLead = n; }
        public boolean isRepeatGroupHeaders() { return repeatGroupHeaders; }
        public void setRepeatGroupHeaders(boolean r) { this.repeatGroupHeaders = r; }
        public boolean isHasPageNumbering() { return hasPageNumbering; }
        public void setHasPageNumbering(boolean h) { this.hasPageNumbering = h; }
        public boolean isHasRunDate() { return hasRunDate; }
        public void setHasRunDate(boolean h) { this.hasRunDate = h; }
        public boolean isHasTotalPages() { return hasTotalPages; }
        public void setHasTotalPages(boolean h) { this.hasTotalPages = h; }
        public List<String> getPageHeaderVars() { return pageHeaderVars; }
        public List<String> getPageFooterVars() { return pageFooterVars; }
    }

    // ──────────────────────────────────────────────────────────────
    // Request Field with full metadata
    // ──────────────────────────────────────────────────────────────
    public static class RequestField {
        private String name;
        private String aggregation;
        private boolean noprint;
        private String alias;
        private String format;
        private String sortDirection;     // ASCENDING / DESCENDING
        private String displayWidth;      // column width
        private String conditionalFormat; // inline WHEN styling
        private boolean isHidden;

        public RequestField() {}
        public RequestField(String name, String aggregation) {
            this.name = name; this.aggregation = aggregation;
        }
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getAggregation() { return aggregation; }
        public void setAggregation(String a) { this.aggregation = a; }
        public boolean isNoprint() { return noprint; }
        public void setNoprint(boolean n) { this.noprint = n; }
        public String getAlias() { return alias; }
        public void setAlias(String a) { this.alias = a; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getSortDirection() { return sortDirection; }
        public void setSortDirection(String s) { this.sortDirection = s; }
        public String getDisplayWidth() { return displayWidth; }
        public void setDisplayWidth(String d) { this.displayWidth = d; }
        public String getConditionalFormat() { return conditionalFormat; }
        public void setConditionalFormat(String c) { this.conditionalFormat = c; }
        public boolean isHidden() { return isHidden; }
        public void setHidden(boolean h) { this.isHidden = h; }
    }

    // ──────────────────────────────────────────────────────────────
    // DEFINE, COMPUTE, RECAP fields
    // ──────────────────────────────────────────────────────────────
    public static class DefineField {
        private String file;
        private String field;
        private String format;
        private String expression;
        private int line;
        private boolean isMultiLine;
        private String rawBlock;

        public String getFile() { return file; }
        public void setFile(String f) { this.file = f; }
        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public boolean isMultiLine() { return isMultiLine; }
        public void setMultiLine(boolean m) { this.isMultiLine = m; }
        public String getRawBlock() { return rawBlock; }
        public void setRawBlock(String r) { this.rawBlock = r; }
    }

    public static class ComputeField {
        private String field;
        private String format;
        private String expression;
        private int line;
        private String breakLevel; // which BY field this compute fires at

        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getBreakLevel() { return breakLevel; }
        public void setBreakLevel(String b) { this.breakLevel = b; }
    }

    public static class RecapField {
        private String field;
        private String format;
        private String expression;
        private int line;
        private String breakField;  // which BY triggers this RECAP
        private String recapType;   // RECAP, RECOMPUTE, COLUMN-TOTAL

        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getBreakField() { return breakField; }
        public void setBreakField(String b) { this.breakField = b; }
        public String getRecapType() { return recapType; }
        public void setRecapType(String r) { this.recapType = r; }
    }

    // ──────────────────────────────────────────────────────────────
    // Filter spec
    // ──────────────────────────────────────────────────────────────
    public static class FilterSpec {
        private int line;
        private String expression;
        private String filterType; // WHERE, IF, WHEN, ACCEPT
        private boolean isParameterized; // contains &variable

        public FilterSpec() {}
        public FilterSpec(int line, String expr, String type) {
            this.line = line; this.expression = expr; this.filterType = type;
        }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
        public String getFilterType() { return filterType; }
        public void setFilterType(String t) { this.filterType = t; }
        public boolean isParameterized() { return isParameterized; }
        public void setParameterized(boolean p) { this.isParameterized = p; }
    }

    // ──────────────────────────────────────────────────────────────
    // JOIN, MATCH, COMBINE
    // ──────────────────────────────────────────────────────────────
    public static class JoinSpec {
        private String leftField;
        private String leftFile;
        private String rightField;
        private String rightFile;
        private String joinType; // INNER, LEFT, CROSS
        private int line;
        private String raw;
        private boolean parsed = true;

        public String getLeftField() { return leftField; }
        public void setLeftField(String l) { this.leftField = l; }
        public String getLeftFile() { return leftFile; }
        public void setLeftFile(String l) { this.leftFile = l; }
        public String getRightField() { return rightField; }
        public void setRightField(String r) { this.rightField = r; }
        public String getRightFile() { return rightFile; }
        public void setRightFile(String r) { this.rightFile = r; }
        public String getJoinType() { return joinType; }
        public void setJoinType(String j) { this.joinType = j; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getRaw() { return raw; }
        public void setRaw(String r) { this.raw = r; }
        public boolean isParsed() { return parsed; }
        public void setParsed(boolean p) { this.parsed = p; }
    }

    public static class MatchSpec {
        private String matchType;  // MATCH, COMBINE
        private String operation;  // OLD-STYLE, NEW-STYLE, ADD, REJECT
        private List<String> files = new ArrayList<>();
        private List<String> matchFields = new ArrayList<>();
        private int line;
        private String raw;

        public String getMatchType() { return matchType; }
        public void setMatchType(String m) { this.matchType = m; }
        public String getOperation() { return operation; }
        public void setOperation(String o) { this.operation = o; }
        public List<String> getFiles() { return files; }
        public List<String> getMatchFields() { return matchFields; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getRaw() { return raw; }
        public void setRaw(String r) { this.raw = r; }
    }

    // ──────────────────────────────────────────────────────────────
    // Conditional Styling
    // ──────────────────────────────────────────────────────────────
    public static class StyleRule {
        private String target;       // COLUMN, ROW, GRID, TABLE
        private String targetField;  // which field the style applies to
        private String condition;    // WHEN expression
        private Map<String, String> properties = new LinkedHashMap<>(); // BACKCOLOR, COLOR, FONT, etc.
        private int line;

        public String getTarget() { return target; }
        public void setTarget(String t) { this.target = t; }
        public String getTargetField() { return targetField; }
        public void setTargetField(String f) { this.targetField = f; }
        public String getCondition() { return condition; }
        public void setCondition(String c) { this.condition = c; }
        public Map<String, String> getProperties() { return properties; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
    }

    public static class GridConfig {
        private boolean enabled;
        private String gridColor;
        private String gridStyle;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean e) { this.enabled = e; }
        public String getGridColor() { return gridColor; }
        public void setGridColor(String g) { this.gridColor = g; }
        public String getGridStyle() { return gridStyle; }
        public void setGridStyle(String g) { this.gridStyle = g; }
    }

    // ──────────────────────────────────────────────────────────────
    // Graph Configuration
    // ──────────────────────────────────────────────────────────────
    public static class GraphConfig {
        private String graphType;    // BAR, LINE, PIE, AREA, SCATTER, HBAR, VBAR, BUBBLE, etc.
        private String lookGraph;
        private String orientation;
        private String legendPosition;
        private boolean show3D;
        private boolean showDataLabels;
        private String xAxisLabel;
        private String yAxisLabel;
        private List<String> seriesColors = new ArrayList<>();

        public String getGraphType() { return graphType; }
        public void setGraphType(String g) { this.graphType = g; }
        public String getLookGraph() { return lookGraph; }
        public void setLookGraph(String l) { this.lookGraph = l; }
        public String getOrientation() { return orientation; }
        public void setOrientation(String o) { this.orientation = o; }
        public String getLegendPosition() { return legendPosition; }
        public void setLegendPosition(String l) { this.legendPosition = l; }
        public boolean isShow3D() { return show3D; }
        public void setShow3D(boolean s) { this.show3D = s; }
        public boolean isShowDataLabels() { return showDataLabels; }
        public void setShowDataLabels(boolean s) { this.showDataLabels = s; }
        public String getXAxisLabel() { return xAxisLabel; }
        public void setXAxisLabel(String x) { this.xAxisLabel = x; }
        public String getYAxisLabel() { return yAxisLabel; }
        public void setYAxisLabel(String y) { this.yAxisLabel = y; }
        public List<String> getSeriesColors() { return seriesColors; }
    }

    // ──────────────────────────────────────────────────────────────
    // Drill-Down Specification
    // ──────────────────────────────────────────────────────────────
    public static class DrillDownSpec {
        private String sourceField;
        private String targetProcedure;  // the .fex to drill into
        private List<String> passedParameters = new ArrayList<>();
        private int line;

        public String getSourceField() { return sourceField; }
        public void setSourceField(String s) { this.sourceField = s; }
        public String getTargetProcedure() { return targetProcedure; }
        public void setTargetProcedure(String t) { this.targetProcedure = t; }
        public List<String> getPassedParameters() { return passedParameters; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
    }

    // ──────────────────────────────────────────────────────────────
    // Self-Service / InfoAssist Metadata
    // ──────────────────────────────────────────────────────────────
    public static class SelfServiceMeta {
        private String toolType;        // INFOASSIST, REPORT_PAINTER, DASHBOARD_DESIGNER
        private String ibifVersion;     // IBIF_ex version header
        private List<String> savedFilters = new ArrayList<>();
        private List<String> savedSorts = new ArrayList<>();
        private String templateName;
        private List<String> availableFields = new ArrayList<>();
        private boolean allowDrillDown;
        private boolean allowExport;
        private boolean allowFilter;
        private boolean allowSort;
        private boolean allowPivot;
        private boolean isInteractive;

        public String getToolType() { return toolType; }
        public void setToolType(String t) { this.toolType = t; }
        public String getIbifVersion() { return ibifVersion; }
        public void setIbifVersion(String v) { this.ibifVersion = v; }
        public List<String> getSavedFilters() { return savedFilters; }
        public List<String> getSavedSorts() { return savedSorts; }
        public String getTemplateName() { return templateName; }
        public void setTemplateName(String t) { this.templateName = t; }
        public List<String> getAvailableFields() { return availableFields; }
        public boolean isAllowDrillDown() { return allowDrillDown; }
        public void setAllowDrillDown(boolean a) { this.allowDrillDown = a; }
        public boolean isAllowExport() { return allowExport; }
        public void setAllowExport(boolean a) { this.allowExport = a; }
        public boolean isAllowFilter() { return allowFilter; }
        public void setAllowFilter(boolean a) { this.allowFilter = a; }
        public boolean isAllowSort() { return allowSort; }
        public void setAllowSort(boolean a) { this.allowSort = a; }
        public boolean isAllowPivot() { return allowPivot; }
        public void setAllowPivot(boolean a) { this.allowPivot = a; }
        public boolean isInteractive() { return isInteractive; }
        public void setInteractive(boolean i) { this.isInteractive = i; }
    }

    // ──────────────────────────────────────────────────────────────
    // Active Report Configuration
    // ──────────────────────────────────────────────────────────────
    public static class ActiveReportConfig {
        private String arVersion;       // ARVERSION
        private boolean hasInteractiveFilters;
        private boolean hasInteractiveSorting;
        private boolean hasRollup;
        private boolean hasPivot;
        private boolean hasCharts;
        private boolean hasExport;
        private List<String> interactiveFields = new ArrayList<>();
        private List<String> rollupFields = new ArrayList<>();

        public String getArVersion() { return arVersion; }
        public void setArVersion(String a) { this.arVersion = a; }
        public boolean isHasInteractiveFilters() { return hasInteractiveFilters; }
        public void setHasInteractiveFilters(boolean h) { this.hasInteractiveFilters = h; }
        public boolean isHasInteractiveSorting() { return hasInteractiveSorting; }
        public void setHasInteractiveSorting(boolean h) { this.hasInteractiveSorting = h; }
        public boolean isHasRollup() { return hasRollup; }
        public void setHasRollup(boolean h) { this.hasRollup = h; }
        public boolean isHasPivot() { return hasPivot; }
        public void setHasPivot(boolean h) { this.hasPivot = h; }
        public boolean isHasCharts() { return hasCharts; }
        public void setHasCharts(boolean h) { this.hasCharts = h; }
        public boolean isHasExport() { return hasExport; }
        public void setHasExport(boolean h) { this.hasExport = h; }
        public List<String> getInteractiveFields() { return interactiveFields; }
        public List<String> getRollupFields() { return rollupFields; }
    }

    // ──────────────────────────────────────────────────────────────
    // Dialogue Manager Commands
    // ──────────────────────────────────────────────────────────────
    public static class DMCommand {
        private String command;  // IF, GOTO, RUN, REPEAT, TYPE, READ, HTMLFORM
        private String arguments;
        private int line;
        private String label;

        public DMCommand() {}
        public DMCommand(String command, String arguments, int line) {
            this.command = command; this.arguments = arguments; this.line = line;
        }
        public String getCommand() { return command; }
        public void setCommand(String c) { this.command = c; }
        public String getArguments() { return arguments; }
        public void setArguments(String a) { this.arguments = a; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getLabel() { return label; }
        public void setLabel(String l) { this.label = l; }
    }

    // ──────────────────────────────────────────────────────────────
    // Misc: Variables, Includes, Prompts, HOLD, RUN chains
    // ──────────────────────────────────────────────────────────────
    public static class Variable {
        private String name;
        private String value;
        private int line;
        private boolean isGlobal; // &&var vs &var
        private String dataType;  // detected type

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getValue() { return value; }
        public void setValue(String v) { this.value = v; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public boolean isGlobal() { return isGlobal; }
        public void setGlobal(boolean g) { this.isGlobal = g; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
    }

    public static class IncludeRef {
        private String path;
        private int line;
        public String getPath() { return path; }
        public void setPath(String p) { this.path = p; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
    }

    public static class PromptSpec {
        private int line;
        private String text;
        private String paramName;
        private String paramType;     // ALPHA, INTEGER, DATE
        private String defaultValue;
        private List<String> allowedValues = new ArrayList<>();
        private boolean isRequired;
        private String description;

        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getText() { return text; }
        public void setText(String t) { this.text = t; }
        public String getParamName() { return paramName; }
        public void setParamName(String p) { this.paramName = p; }
        public String getParamType() { return paramType; }
        public void setParamType(String t) { this.paramType = t; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
        public List<String> getAllowedValues() { return allowedValues; }
        public boolean isRequired() { return isRequired; }
        public void setRequired(boolean r) { this.isRequired = r; }
        public String getDescription() { return description; }
        public void setDescription(String d) { this.description = d; }
    }

    public static class HoldSpec {
        private int line;
        private String text;
        private String holdName;
        private String holdFormat;  // ALPHA, FOCUS, COMMA, HTML, XLSX, PDF
        private boolean isPcHold;
        private String targetFile;

        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getText() { return text; }
        public void setText(String t) { this.text = t; }
        public String getHoldName() { return holdName; }
        public void setHoldName(String h) { this.holdName = h; }
        public String getHoldFormat() { return holdFormat; }
        public void setHoldFormat(String f) { this.holdFormat = f; }
        public boolean isPcHold() { return isPcHold; }
        public void setPcHold(boolean p) { this.isPcHold = p; }
        public String getTargetFile() { return targetFile; }
        public void setTargetFile(String t) { this.targetFile = t; }
    }

    public static class RunChain {
        private String targetProcedure;
        private List<String> parameters = new ArrayList<>();
        private int line;

        public String getTargetProcedure() { return targetProcedure; }
        public void setTargetProcedure(String t) { this.targetProcedure = t; }
        public List<String> getParameters() { return parameters; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
    }
}
