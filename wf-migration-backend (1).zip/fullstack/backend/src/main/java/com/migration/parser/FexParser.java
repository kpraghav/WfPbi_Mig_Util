package com.migration.parser;

import com.migration.model.ParsedFexFile;
import com.migration.model.ParsedFexFile.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.regex.*;

/**
 * Production-grade WebFocus 7/8 FOCEXEC parser.
 * 
 * Comprehensive coverage:
 * ─ TABLE FILE / GRAPH FILE requests with all options
 * ─ DEFINE FILE blocks (multi-line expressions)
 * ─ COMPUTE / RECAP / RECOMPUTE
 * ─ JOIN / MATCH FILE / COMBINE
 * ─ BY / ACROSS / WITHIN grouping
 * ─ PAGE-BREAK / SUBTOTAL / COLUMN-TOTAL / ROW-TOTAL
 * ─ HEADING / FOOTING / SUBHEAD / SUBFOOT with page variables
 * ─ ON TABLE SET PAGE, LINES, STYLE
 * ─ Conditional styling (SET STYLE * ... ENDSTYLE / WHEN)
 * ─ ACCEPT / PROMPT parameters
 * ─ -SET / -IF / -GOTO / -RUN / -REPEAT / -TYPE (Dialogue Manager)
 * ─ HOLD / PCHOLD / SAVE output
 * ─ Active Report detection (ARVERSION, HOLDLIST)
 * ─ Self-Service detection (IBIF_ex headers, InfoAssist markers)
 * ─ Dashboard detection (HTML composite markers)
 * ─ Drill-down references (FOCEXEC hyperlinks)
 * ─ Grid configuration
 * ─ Graph type and configuration
 */
@Service
public class FexParser {

    private static final Set<String> AGG_KEYWORDS = Set.of(
        "PRINT", "SUM", "COUNT", "CNT", "AVG", "MIN", "MAX", "PCT",
        "LIST", "FIRST", "LAST", "MEDIAN", "STDEV"
    );

    private static final Set<String> SKIP_TOKENS = Set.of(
        "NOPRINT", "AS", "AND", "TOTAL", "SUBTOTAL", "SUB-TOTAL", "PAGE-BREAK"
    );

    public ParsedFexFile parse(String content, String fileName) {
        ParsedFexFile result = new ParsedFexFile();
        result.setFileName(fileName);
        String[] rawLines = content.split("\\n");
        List<String> lines = new ArrayList<>();
        for (String l : rawLines) lines.add(l.stripTrailing());
        result.setRawLineCount(lines.size());

        detectClassification(content, result);

        int i = 0;
        while (i < lines.size()) {
            String line = lines.get(i).trim();
            String upper = line.toUpperCase();

            if (line.isEmpty() || upper.startsWith("-*")) {
                if (upper.startsWith("-*")) result.getComments().add(line);
                i++; continue;
            }

            // ── Dialogue Manager Commands ────────────────────────
            if (upper.startsWith("-SET ") || upper.startsWith("-SET\t")) {
                parseSetVariable(line, i, result); i++; continue;
            }
            if (upper.startsWith("-IF ") || upper.startsWith("-IF\t")) {
                result.getDialogueManagerCommands().add(new DMCommand("IF", line.substring(3).trim(), i + 1));
                i++; continue;
            }
            if (upper.startsWith("-GOTO ")) {
                result.getDialogueManagerCommands().add(new DMCommand("GOTO", line.substring(5).trim(), i + 1));
                i++; continue;
            }
            if (upper.startsWith("-RUN ")) {
                parseRunChain(line, i, result); i++; continue;
            }
            if (upper.startsWith("-REPEAT")) {
                result.getDialogueManagerCommands().add(new DMCommand("REPEAT", line, i + 1));
                i++; continue;
            }
            if (upper.startsWith("-TYPE ")) {
                result.getDialogueManagerCommands().add(new DMCommand("TYPE", line.substring(5).trim(), i + 1));
                i++; continue;
            }
            if (upper.startsWith("-HTMLFORM") || upper.startsWith("-HTML")) {
                result.getDialogueManagerCommands().add(new DMCommand("HTMLFORM", line, i + 1));
                result.getClassification().setDashboard(true);
                i++; continue;
            }
            if (upper.matches("^-[A-Z_]+\\s*$") || upper.startsWith("-LABEL")) {
                // Label line
                DMCommand dm = new DMCommand("LABEL", line, i + 1);
                dm.setLabel(line.replaceAll("^-", "").trim());
                result.getDialogueManagerCommands().add(dm);
                i++; continue;
            }

            // ── INCLUDE ──────────────────────────────────────────
            if (upper.startsWith("-INCLUDE") || upper.startsWith("- INCLUDE")) {
                Matcher m = Pattern.compile("-\\s*INCLUDE\\s+(.+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (m.find()) {
                    IncludeRef ref = new IncludeRef();
                    ref.setPath(m.group(1).trim());
                    ref.setLine(i + 1);
                    result.getIncludes().add(ref);
                }
                i++; continue;
            }

            // ── ACCEPT / PROMPT ──────────────────────────────────
            if (upper.startsWith("ACCEPT") || upper.matches("^-?\\s*PROMPT\\b.*")) {
                parsePrompt(line, i, result); i++; continue;
            }

            // ── DEFINE FILE ──────────────────────────────────────
            if (upper.startsWith("DEFINE FILE")) {
                i = parseDefineBlock(lines, i, result); continue;
            }

            // ── JOIN ─────────────────────────────────────────────
            if (upper.startsWith("JOIN")) {
                i = parseJoin(lines, i, result); continue;
            }

            // ── MATCH FILE ───────────────────────────────────────
            if (upper.startsWith("MATCH FILE") || upper.startsWith("COMBINE FILE")) {
                i = parseMatchCombine(lines, i, result); continue;
            }

            // ── TABLE FILE / GRAPH FILE ──────────────────────────
            if (upper.startsWith("TABLE FILE") || upper.startsWith("GRAPH FILE")) {
                i = parseRequest(lines, i, result); continue;
            }

            // ── Standalone HOLD ──────────────────────────────────
            if (upper.startsWith("HOLD") || upper.startsWith("PCHOLD") || upper.startsWith("SAVE")) {
                parseHold(line, i, result); i++; continue;
            }

            i++;
        }

        classifyParameterization(result);
        return result;
    }

    // ══════════════════════════════════════════════════════════════
    // Classification: detect what kind of WF asset this is
    // ══════════════════════════════════════════════════════════════
    private void detectClassification(String content, ParsedFexFile result) {
        String upper = content.toUpperCase();
        FileClassification cls = result.getClassification();

        // InfoAssist / Self-Service
        if (upper.contains("IBIF_EX") || upper.contains("CREATED BY INFOASSIST") ||
            upper.contains("REPORT PAINTER") || upper.contains("-DEFAULTH")) {
            cls.setSelfServiceReport(true);
            SelfServiceMeta ssm = new SelfServiceMeta();
            ssm.setToolType(upper.contains("INFOASSIST") ? "INFOASSIST" : "REPORT_PAINTER");
            if (upper.contains("IBIF_EX")) {
                Matcher vm = Pattern.compile("IBIF_EX\\s*=\\s*([\\d.]+)").matcher(content);
                if (vm.find()) ssm.setIbifVersion(vm.group(1));
            }
            ssm.setAllowDrillDown(true);
            ssm.setAllowExport(true);
            ssm.setAllowFilter(true);
            ssm.setAllowSort(true);
            ssm.setInteractive(true);
            result.setSelfService(ssm);
        }

        // Active Report
        if (upper.contains("ARVERSION") || upper.contains("HOLDLIST") ||
            upper.contains("ON TABLE SET HOLDLIST") || upper.contains("ACTIVERESPON")) {
            cls.setActiveReport(true);
            ActiveReportConfig arc = new ActiveReportConfig();
            Matcher arv = Pattern.compile("ARVERSION\\s*=?\\s*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(content);
            if (arv.find()) arc.setArVersion(arv.group(1));
            arc.setHasInteractiveFilters(true);
            arc.setHasInteractiveSorting(true);
            arc.setHasExport(true);
            if (upper.contains("PIVOT") || upper.contains("ACROSS")) arc.setHasPivot(true);
            result.setActiveReportConfig(arc);
        }

        // Dashboard / Composite
        if (upper.contains("-HTMLFORM") || upper.contains("COMPOUND LAYOUT") ||
            upper.contains("DASHBOARD") || upper.contains("IFRAME") ||
            upper.contains("<HTML") || upper.contains("-HTML")) {
            cls.setDashboard(true);
        }

        // Paginated (heuristic: PAGE-BREAK or page variables)
        if (upper.contains("PAGE-BREAK") || upper.contains("TABPAGENO") ||
            upper.contains("TABLASTPAGE") || upper.contains("SET PAGE") ||
            upper.contains("SET LINES") || upper.contains("RECAP") ||
            upper.contains("RECOMPUTE") || upper.contains("SUBHEAD") ||
            upper.contains("SUBFOOT")) {
            cls.setPaginatedReport(true);
        }

        // Cross-tab
        if (upper.contains("ACROSS ")) cls.setCrossTab(true);

        // Conditional formatting
        if (upper.contains("SET STYLE") && (upper.contains("WHEN") || upper.contains("BACKCOLOR"))) {
            cls.setConditionalFormatting(true);
        }

        // Drill-down
        if (upper.contains("FOCEXEC") && upper.contains("HREF") || upper.contains("-RUN")) {
            cls.setDrillDown(true);
        }

        // ETL / HOLD chain
        if (upper.contains("ON TABLE HOLD") || upper.contains("PCHOLD") ||
            (countOccurrences(upper, "TABLE FILE") > 1 && upper.contains("HOLD"))) {
            cls.setEtlProcedure(true);
        }

        // Output type detection
        if (upper.contains("FORMAT HTML") || upper.contains("FORMAT XLSX") ||
            upper.contains("FORMAT PDF") || upper.contains("FORMAT CSV")) {
            Matcher fm = Pattern.compile("FORMAT\\s+(HTML|XLSX|PDF|CSV|EXCEL|EXL2K|AHTML|DHTML)",
                Pattern.CASE_INSENSITIVE).matcher(content);
            if (fm.find()) cls.setOutputType(fm.group(1).toUpperCase());
        }
        if (upper.contains("AHTML") || upper.contains("DHTML") || upper.contains("ACTIVE")) {
            cls.setOutputType("ACTIVE_HTML");
        }
    }

    private int countOccurrences(String text, String sub) {
        int count = 0, idx = 0;
        while ((idx = text.indexOf(sub, idx)) != -1) { count++; idx += sub.length(); }
        return count;
    }

    // ══════════════════════════════════════════════════════════════
    // DEFINE FILE block (multi-line expressions)
    // ══════════════════════════════════════════════════════════════
    private int parseDefineBlock(List<String> lines, int start, ParsedFexFile result) {
        String header = lines.get(start).trim();
        Matcher fm = Pattern.compile("DEFINE\\s+FILE\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(header);
        String file = fm.find() ? fm.group(1) : "UNKNOWN";

        int i = start + 1;
        StringBuilder currentExpr = new StringBuilder();
        String currentField = null, currentFormat = null;
        int fieldLine = -1;

        while (i < lines.size()) {
            String line = lines.get(i).trim();
            String upper = line.toUpperCase();
            if (upper.equals("END") || upper.equals("END;")) {
                flushDefine(file, currentField, currentFormat, currentExpr, fieldLine, result);
                return i + 1;
            }
            if (line.isEmpty() || upper.startsWith("-*")) { i++; continue; }

            // New field definition
            Matcher defM = Pattern.compile("^(\\w+)/(\\w\\d+(?:\\.\\d+)?)\\s*=\\s*(.*)", Pattern.CASE_INSENSITIVE).matcher(line);
            if (defM.find()) {
                flushDefine(file, currentField, currentFormat, currentExpr, fieldLine, result);
                currentField = defM.group(1);
                currentFormat = defM.group(2);
                currentExpr = new StringBuilder(defM.group(3).replaceAll(";\\s*$", "").trim());
                fieldLine = i + 1;
            } else if (currentField != null) {
                // Multi-line continuation
                String cont = line.replaceAll(";\\s*$", "").trim();
                if (!cont.isEmpty()) currentExpr.append(" ").append(cont);
            } else {
                // Simple assignment without format
                Matcher simpleM = Pattern.compile("^(\\w+)\\s*=\\s*(.*)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (simpleM.find()) {
                    flushDefine(file, currentField, currentFormat, currentExpr, fieldLine, result);
                    currentField = simpleM.group(1);
                    currentFormat = "UNKNOWN";
                    currentExpr = new StringBuilder(simpleM.group(2).replaceAll(";\\s*$", "").trim());
                    fieldLine = i + 1;
                }
            }
            i++;
        }
        flushDefine(file, currentField, currentFormat, currentExpr, fieldLine, result);
        return i;
    }

    private void flushDefine(String file, String field, String format, StringBuilder expr, int line, ParsedFexFile result) {
        if (field == null) return;
        DefineField def = new DefineField();
        def.setFile(file); def.setField(field); def.setFormat(format);
        def.setExpression(expr.toString().trim()); def.setLine(line);
        def.setMultiLine(expr.toString().contains("\n") || expr.length() > 80);
        result.getDefines().add(def);
    }

    // ══════════════════════════════════════════════════════════════
    // JOIN
    // ══════════════════════════════════════════════════════════════
    private int parseJoin(List<String> lines, int start, ParsedFexFile result) {
        StringBuilder sb = new StringBuilder(lines.get(start).trim());
        int i = start + 1;
        while (i < lines.size()) {
            String l = lines.get(i).trim();
            String u = l.toUpperCase();
            if (u.equals("END") || u.equals("END;") || u.startsWith("TABLE") ||
                u.startsWith("GRAPH") || u.startsWith("DEFINE") || u.startsWith("JOIN") ||
                u.startsWith("MATCH") || l.isEmpty()) break;
            sb.append(" ").append(l);
            i++;
        }
        JoinSpec join = new JoinSpec();
        join.setLine(start + 1);
        join.setRaw(sb.toString());

        String text = sb.toString();
        // Detect join type
        if (text.toUpperCase().contains("LEFT")) join.setJoinType("LEFT");
        else if (text.toUpperCase().contains("CROSS")) join.setJoinType("CROSS");
        else join.setJoinType("INNER");

        Matcher m = Pattern.compile("JOIN\\s+(\\w+)\\s+(?:IN\\s+)?(\\w+)\\s+TO\\s+(\\w+)\\s+(?:IN\\s+)?(\\w+)",
            Pattern.CASE_INSENSITIVE).matcher(text);
        if (m.find()) {
            join.setLeftField(m.group(1)); join.setLeftFile(m.group(2));
            join.setRightField(m.group(3)); join.setRightFile(m.group(4));
        } else { join.setParsed(false); }

        result.getJoins().add(join);
        return i;
    }

    // ══════════════════════════════════════════════════════════════
    // MATCH FILE / COMBINE FILE
    // ══════════════════════════════════════════════════════════════
    private int parseMatchCombine(List<String> lines, int start, ParsedFexFile result) {
        StringBuilder sb = new StringBuilder(lines.get(start).trim());
        int i = start + 1;
        while (i < lines.size()) {
            String l = lines.get(i).trim();
            String u = l.toUpperCase();
            if (u.equals("END") || u.equals("END;") || u.startsWith("TABLE") || u.startsWith("GRAPH")) break;
            sb.append(" ").append(l);
            i++;
        }
        MatchSpec ms = new MatchSpec();
        ms.setLine(start + 1);
        ms.setRaw(sb.toString());
        ms.setMatchType(sb.toString().toUpperCase().startsWith("MATCH") ? "MATCH" : "COMBINE");

        // Extract file names
        Matcher fm = Pattern.compile("FILE\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(sb.toString());
        while (fm.find()) ms.getFiles().add(fm.group(1));

        // Extract match fields
        Matcher bm = Pattern.compile("BY\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(sb.toString());
        while (bm.find()) ms.getMatchFields().add(bm.group(1));

        if (sb.toString().toUpperCase().contains("OLD")) ms.setOperation("OLD-STYLE");
        else if (sb.toString().toUpperCase().contains("ADD")) ms.setOperation("ADD");
        else ms.setOperation("NEW-STYLE");

        result.getMatches().add(ms);
        return i;
    }

    // ══════════════════════════════════════════════════════════════
    // TABLE FILE / GRAPH FILE — the main request parser
    // ══════════════════════════════════════════════════════════════
    private int parseRequest(List<String> lines, int start, ParsedFexFile result) {
        String header = lines.get(start).trim();
        boolean isGraph = header.toUpperCase().startsWith("GRAPH");
        Matcher fm = Pattern.compile("(TABLE|GRAPH)\\s+FILE\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(header);
        String file = fm.find() ? fm.group(2) : "UNKNOWN";

        TableRequest req = new TableRequest();
        req.setType(isGraph ? "GRAPH" : "TABLE");
        req.setFile(file);
        req.setLine(start + 1);
        if (isGraph) req.setGraphConfig(new GraphConfig());

        boolean inStyleBlock = false;
        StringBuilder styleBlock = new StringBuilder();

        int i = start + 1;
        while (i < lines.size()) {
            String line = lines.get(i).trim();
            String upper = line.toUpperCase();
            req.getRaw().add(line);

            if (upper.equals("END") || upper.equals("END;")) { i++; break; }
            if (upper.startsWith("TABLE FILE") || upper.startsWith("GRAPH FILE") || upper.startsWith("DEFINE FILE")) break;

            // ── Style block parsing ──────────────────────
            if (upper.contains("ENDSTYLE") || upper.equals("$")) {
                if (inStyleBlock) {
                    parseStyleBlock(styleBlock.toString(), req);
                    inStyleBlock = false;
                    styleBlock = new StringBuilder();
                }
                i++; continue;
            }
            if (inStyleBlock) {
                styleBlock.append(line).append("\n");
                i++; continue;
            }
            if (upper.contains("SET STYLE") && upper.contains("*")) {
                inStyleBlock = true;
                i++; continue;
            }

            // ── Aggregation lines ────────────────────────
            boolean isAgg = false;
            for (String aggKey : AGG_KEYWORDS) {
                if (upper.startsWith(aggKey + " ") || upper.startsWith(aggKey + "\t")) {
                    parseAggLine(line, upper, aggKey, req);
                    isAgg = true; break;
                }
            }
            if (isAgg) { i++; continue; }

            // ── BY ───────────────────────────────────────
            if (upper.startsWith("BY ") || upper.startsWith("BY\t")) {
                parseByClause(line, upper, req);
                i++; continue;
            }

            // ── ACROSS ───────────────────────────────────
            if (upper.startsWith("ACROSS ")) {
                Matcher am = Pattern.compile("ACROSS\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (am.find()) req.getAcrossFields().add(am.group(1));
                result.getClassification().setCrossTab(true);
                i++; continue;
            }

            // ── WITHIN ───────────────────────────────────
            if (upper.startsWith("WITHIN ")) {
                Matcher wm = Pattern.compile("WITHIN\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                if (wm.find()) req.setWithinField(wm.group(1));
                i++; continue;
            }

            // ── WHERE / IF filters ───────────────────────
            if (upper.startsWith("WHERE ") || upper.startsWith("IF ")) {
                String type = upper.startsWith("WHERE") ? "WHERE" : "IF";
                FilterSpec fs = new FilterSpec(i + 1, line, type);
                fs.setParameterized(line.contains("&"));
                req.getFilters().add(fs);
                i++; continue;
            }

            // ── COMPUTE ──────────────────────────────────
            if (upper.startsWith("COMPUTE ")) {
                parseCompute(line, i, req);
                i++; continue;
            }

            // ── RECAP / RECOMPUTE ────────────────────────
            if (upper.startsWith("RECAP ") || upper.startsWith("RECOMPUTE ")) {
                parseRecap(line, i, upper.startsWith("RECAP") ? "RECAP" : "RECOMPUTE", req);
                result.getClassification().setPaginatedReport(true);
                i++; continue;
            }

            // ── HEADING / FOOTING / SUBHEAD / SUBFOOT ────
            if (upper.startsWith("HEADING ") || upper.startsWith("SUBHEAD ") ||
                upper.startsWith("FOOTING ") || upper.startsWith("SUBFOOT ")) {
                parseHeaderFooter(line, upper, req);
                i++; continue;
            }

            // ── ON TABLE / ON GRAPH ──────────────────────
            if (upper.startsWith("ON TABLE") || upper.startsWith("ON GRAPH")) {
                parseOnTableGraph(line, upper, req, result);
                i++; continue;
            }

            // ── HOLDLIST (Active Report) ─────────────────
            if (upper.contains("HOLDLIST")) {
                req.setActiveReport(true);
                result.getClassification().setActiveReport(true);
                Matcher hm = Pattern.compile("HOLDLIST\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
                while (hm.find()) req.getHoldListFields().add(hm.group(1));
                i++; continue;
            }

            // ── Drill-down (FOCEXEC href) ────────────────
            if (upper.contains("FOCEXEC") || upper.contains("HREF")) {
                parseDrillDown(line, i, req, result);
                i++; continue;
            }

            i++;
        }

        // Post-process pagination
        detectPagination(req);

        result.getRequests().add(req);
        return i;
    }

    // ── Aggregation line parsing ─────────────────────────────────
    private void parseAggLine(String line, String upper, String aggKey, TableRequest req) {
        Matcher am = Pattern.compile("^" + aggKey + "\\s+(.+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!am.find()) return;
        String fieldsPart = am.group(1);
        String[] tokens = fieldsPart.split("\\s+");
        String agg = (aggKey.equals("PRINT") || aggKey.equals("LIST")) ? null : aggKey;

        for (int t = 0; t < tokens.length; t++) {
            String tok = tokens[t];
            String tokUpper = tok.toUpperCase();

            if (tokUpper.equals("AS") && t + 1 < tokens.length) {
                // Alias — might be quoted, collect until closing quote
                StringBuilder alias = new StringBuilder();
                t++;
                String next = tokens[t];
                if (next.startsWith("'") || next.startsWith("\"")) {
                    char q = next.charAt(0);
                    alias.append(next.substring(1));
                    while (!next.endsWith(String.valueOf(q)) && t + 1 < tokens.length) {
                        t++;
                        next = tokens[t];
                        alias.append(" ").append(next);
                    }
                    String a = alias.toString();
                    if (a.endsWith("'") || a.endsWith("\"")) a = a.substring(0, a.length() - 1);
                    if (!req.getFields().isEmpty()) req.getFields().get(req.getFields().size() - 1).setAlias(a);
                } else {
                    if (!req.getFields().isEmpty()) req.getFields().get(req.getFields().size() - 1).setAlias(next.replaceAll("['\"]", ""));
                }
            } else if (tokUpper.equals("NOPRINT")) {
                if (!req.getFields().isEmpty()) req.getFields().get(req.getFields().size() - 1).setNoprint(true);
            } else if (SKIP_TOKENS.contains(tokUpper) || tok.startsWith("-*") || tok.isEmpty()) {
                continue;
            } else {
                RequestField rf = new RequestField();
                rf.setName(tok.replaceAll("[;,]", ""));
                rf.setAggregation(agg);
                req.getFields().add(rf);
            }
        }
    }

    // ── BY clause ────────────────────────────────────────────────
    private void parseByClause(String line, String upper, TableRequest req) {
        Matcher bm = Pattern.compile("^BY\\s+(.+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!bm.find()) return;
        String[] tokens = bm.group(1).split("\\s+");

        for (int t = 0; t < tokens.length; t++) {
            String tok = tokens[t].toUpperCase().replaceAll("[;,]", "");
            if (tok.equals("PAGE-BREAK")) {
                req.getPageBreaks().add(req.getGroupBy().isEmpty() ? "" : req.getGroupBy().get(req.getGroupBy().size() - 1));
                req.getPagination().setHasPageBreaks(true);
            } else if (tok.equals("SUBTOTAL") || tok.equals("SUB-TOTAL")) {
                req.setSubTotals(true);
            } else if (tok.equals("TOTAL")) {
                req.setColumnTotal(true);
            } else if (tok.equals("NOPRINT") || tok.equals("AS") || tok.equals("AND")) {
                if (tok.equals("AS") && t + 1 < tokens.length) t++; // skip alias
            } else if (tok.equals("ASCENDING") || tok.equals("DESCENDING") || tok.equals("ASC") || tok.equals("DESC")) {
                // Sort direction
                if (!req.getGroupBy().isEmpty()) {
                    req.getSortBy().add(req.getGroupBy().get(req.getGroupBy().size() - 1) + " " + tok);
                }
            } else if (!tok.isEmpty()) {
                req.getGroupBy().add(tokens[t].replaceAll("[;,]", ""));
            }
        }
    }

    // ── COMPUTE ──────────────────────────────────────────────────
    private void parseCompute(String line, int lineNum, TableRequest req) {
        Matcher cm = Pattern.compile("COMPUTE\\s+(\\w+)(?:/(\\w\\d+(?:\\.\\d+)?))?\\s*=\\s*(.+)",
            Pattern.CASE_INSENSITIVE).matcher(line);
        if (!cm.find()) return;
        ComputeField cf = new ComputeField();
        cf.setField(cm.group(1));
        cf.setFormat(cm.group(2) != null ? cm.group(2) : "UNKNOWN");
        cf.setExpression(cm.group(3).replaceAll(";\\s*$", "").trim());
        cf.setLine(lineNum + 1);
        req.getComputes().add(cf);
    }

    // ── RECAP / RECOMPUTE ────────────────────────────────────────
    private void parseRecap(String line, int lineNum, String type, TableRequest req) {
        Matcher rm = Pattern.compile("(?:RECAP|RECOMPUTE)\\s+(\\w+)(?:/(\\w\\d+(?:\\.\\d+)?))?\\s*=\\s*(.+)",
            Pattern.CASE_INSENSITIVE).matcher(line);
        if (!rm.find()) return;
        RecapField rf = new RecapField();
        rf.setField(rm.group(1));
        rf.setFormat(rm.group(2) != null ? rm.group(2) : "UNKNOWN");
        rf.setExpression(rm.group(3).replaceAll(";\\s*$", "").trim());
        rf.setLine(lineNum + 1);
        rf.setRecapType(type);
        // Infer break field from most recent BY
        if (!req.getGroupBy().isEmpty()) {
            rf.setBreakField(req.getGroupBy().get(req.getGroupBy().size() - 1));
        }
        req.getRecaps().add(rf);
    }

    // ── HEADING / FOOTING ────────────────────────────────────────
    private void parseHeaderFooter(String line, String upper, TableRequest req) {
        Matcher m = Pattern.compile("^(HEADING|FOOTING|SUBHEAD|SUBFOOT)\\s+(.*)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!m.find()) return;
        String type = m.group(1).toUpperCase();
        String content = m.group(2).trim();

        switch (type) {
            case "HEADING" -> req.getHeadings().add(content);
            case "FOOTING" -> req.getFootings().add(content);
            case "SUBHEAD" -> req.getSubHeadings().add(content);
            case "SUBFOOT" -> req.getSubFootings().add(content);
        }

        // Detect page variables for paginated report
        PaginationConfig pg = req.getPagination();
        if (content.contains("<TABPAGENO>") || content.contains("TABPAGENO")) pg.setHasPageNumbering(true);
        if (content.contains("<TABLASTPAGE>")) pg.setHasTotalPages(true);
        if (content.contains("<TOD>") || content.contains("<D>") || content.contains("<DTAB>")) pg.setHasRunDate(true);

        // Extract variable references
        Matcher vm = Pattern.compile("&(\\w+)").matcher(content);
        while (vm.find()) {
            if (type.contains("HEAD")) pg.getPageHeaderVars().add(vm.group(1));
            else pg.getPageFooterVars().add(vm.group(1));
        }
    }

    // ── ON TABLE / ON GRAPH ──────────────────────────────────────
    private void parseOnTableGraph(String line, String upper, TableRequest req, ParsedFexFile result) {
        req.getOnTableSet().add(line);

        // Output format
        if (upper.contains("PCHOLD") || upper.contains("HOLD")) {
            Matcher fm = Pattern.compile("FORMAT\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(upper);
            req.setOutputFormat(fm.find() ? fm.group(1) : "HOLD");

            // Parse HOLD AS name
            Matcher hm = Pattern.compile("HOLD\\s+AS\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
            if (hm.find()) {
                HoldSpec hs = new HoldSpec();
                hs.setLine(0);
                hs.setHoldName(hm.group(1));
                hs.setHoldFormat(req.getOutputFormat());
                hs.setPcHold(upper.contains("PCHOLD"));
                hs.setText(line);
                result.getHolds().add(hs);
                result.getClassification().setEtlProcedure(true);
            }
        }

        // Column/Row totals
        if (upper.contains("COLUMN-TOTAL")) req.setColumnTotal(true);
        if (upper.contains("ROW-TOTAL")) req.setRowTotal(true);

        // Page settings
        Matcher lm = Pattern.compile("SET\\s+LINES\\s+(\\d+)", Pattern.CASE_INSENSITIVE).matcher(upper);
        if (lm.find()) req.getPagination().setLinesPerPage(Integer.parseInt(lm.group(1)));
        if (upper.contains("NOPAGE")) req.getPagination().setNoPage(true);
        if (upper.contains("NOLEAD")) req.getPagination().setNoLead(true);

        // Graph config
        if (upper.contains("GRAPHTYPE") && req.getGraphConfig() != null) {
            Matcher gm = Pattern.compile("GRAPHTYPE\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
            if (gm.find()) req.getGraphConfig().setGraphType(gm.group(1));
        }
        if (upper.contains("LOOKGRAPH") && req.getGraphConfig() != null) {
            Matcher lk = Pattern.compile("LOOKGRAPH\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
            if (lk.find()) req.getGraphConfig().setLookGraph(lk.group(1));
        }

        // Active Report
        if (upper.contains("HOLDLIST") || upper.contains("ARVERSION")) {
            req.setActiveReport(true);
            result.getClassification().setActiveReport(true);
        }
    }

    // ── Conditional Style Block ──────────────────────────────────
    private void parseStyleBlock(String block, TableRequest req) {
        String[] parts = block.split("\\$|\\n");
        for (String part : parts) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            StyleRule rule = new StyleRule();

            Matcher cm = Pattern.compile("COLUMN\\s*=\\s*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(p);
            if (cm.find()) { rule.setTarget("COLUMN"); rule.setTargetField(cm.group(1)); }
            else if (p.toUpperCase().contains("GRID")) { rule.setTarget("GRID"); }
            else { rule.setTarget("TABLE"); }

            Matcher wm = Pattern.compile("WHEN\\s*=\\s*(.+?)(?:,|$)", Pattern.CASE_INSENSITIVE).matcher(p);
            if (wm.find()) rule.setCondition(wm.group(1).trim());

            for (String prop : new String[]{"BACKCOLOR", "COLOR", "FONT", "STYLE", "JUSTIFY", "IMAGE", "SIZE"}) {
                Matcher pm = Pattern.compile(prop + "\\s*=\\s*([^,\\$]+)", Pattern.CASE_INSENSITIVE).matcher(p);
                if (pm.find()) rule.getProperties().put(prop, pm.group(1).trim());
            }

            if (rule.getTarget() != null && (!rule.getProperties().isEmpty() || rule.getCondition() != null)) {
                req.getStyleRules().add(rule);
            }

            // Grid config
            if (p.toUpperCase().contains("GRID=ON")) {
                GridConfig gc = new GridConfig();
                gc.setEnabled(true);
                req.setGridConfig(gc);
            }
        }
    }

    // ── Drill-down ───────────────────────────────────────────────
    private void parseDrillDown(String line, int lineNum, TableRequest req, ParsedFexFile result) {
        DrillDownSpec dd = new DrillDownSpec();
        dd.setLine(lineNum + 1);
        Matcher fm = Pattern.compile("FOCEXEC\\s*=\\s*['\"]?([\\w.]+)['\"]?", Pattern.CASE_INSENSITIVE).matcher(line);
        if (fm.find()) dd.setTargetProcedure(fm.group(1));
        Matcher pm = Pattern.compile("&(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        while (pm.find()) dd.getPassedParameters().add(pm.group(1));
        req.getDrillDowns().add(dd);
        result.getClassification().setDrillDown(true);
    }

    // ── Pagination detection ─────────────────────────────────────
    private void detectPagination(TableRequest req) {
        PaginationConfig pg = req.getPagination();
        if (!req.getPageBreaks().isEmpty()) {
            pg.setHasPageBreaks(true);
            pg.getPageBreakFields().addAll(req.getPageBreaks());
        }
        if (!req.getSubHeadings().isEmpty() || !req.getSubFootings().isEmpty()) {
            pg.setRepeatGroupHeaders(true);
        }
        // Any pagination indicators mean this should be a paginated report
        if (pg.isHasPageBreaks() || pg.isHasPageNumbering() || pg.isHasTotalPages() ||
            !req.getRecaps().isEmpty() || !req.getSubHeadings().isEmpty()) {
            // Will be classified as paginated
        }
    }

    // ══════════════════════════════════════════════════════════════
    // Helpers: SET, PROMPT, HOLD, RUN
    // ══════════════════════════════════════════════════════════════
    private void parseSetVariable(String line, int lineNum, ParsedFexFile result) {
        Matcher m = Pattern.compile("-SET\\s+(&{1,2})(\\w+)\\s*=\\s*(.+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (!m.find()) return;
        Variable v = new Variable();
        v.setGlobal(m.group(1).equals("&&"));
        v.setName(m.group(2));
        String val = m.group(3).trim().replaceAll(";$", "");
        v.setValue(val);
        v.setLine(lineNum + 1);
        // Detect type
        if (val.matches("\\d+")) v.setDataType("INTEGER");
        else if (val.matches("\\d+\\.\\d+")) v.setDataType("DECIMAL");
        else if (val.startsWith("'") || val.startsWith("\"")) v.setDataType("ALPHA");
        else v.setDataType("ALPHA");
        result.getVariables().add(v);
    }

    private void parsePrompt(String line, int lineNum, ParsedFexFile result) {
        PromptSpec ps = new PromptSpec();
        ps.setLine(lineNum + 1);
        ps.setText(line);

        // ACCEPT &var [TYPE] [DEFAULT value] [PROMPT 'text']
        Matcher nm = Pattern.compile("&(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (nm.find()) ps.setParamName(nm.group(1));

        Matcher tm = Pattern.compile("TYPE\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (tm.find()) ps.setParamType(tm.group(1));

        Matcher dm = Pattern.compile("DEFAULT\\s+([^,;]+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (dm.find()) ps.setDefaultValue(dm.group(1).trim().replaceAll("['\"]", ""));

        Matcher pm = Pattern.compile("PROMPT\\s+['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE).matcher(line);
        if (pm.find()) ps.setDescription(pm.group(1));

        result.getPrompts().add(ps);
        result.getClassification().setParameterized(true);
    }

    private void parseHold(String line, int lineNum, ParsedFexFile result) {
        HoldSpec hs = new HoldSpec();
        hs.setLine(lineNum + 1);
        hs.setText(line);
        hs.setPcHold(line.toUpperCase().startsWith("PCHOLD"));

        Matcher nm = Pattern.compile("(?:HOLD|PCHOLD|SAVE)\\s+(?:AS\\s+)?(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (nm.find()) hs.setHoldName(nm.group(1));

        Matcher fm = Pattern.compile("FORMAT\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (fm.find()) hs.setHoldFormat(fm.group(1));

        result.getHolds().add(hs);
        result.getClassification().setEtlProcedure(true);
    }

    private void parseRunChain(String line, int lineNum, ParsedFexFile result) {
        RunChain rc = new RunChain();
        rc.setLine(lineNum + 1);
        Matcher rm = Pattern.compile("-RUN\\s+(\\S+)", Pattern.CASE_INSENSITIVE).matcher(line);
        if (rm.find()) rc.setTargetProcedure(rm.group(1));
        result.getRunChains().add(rc);
        result.getDialogueManagerCommands().add(new DMCommand("RUN", line.substring(4).trim(), lineNum + 1));
    }

    private void classifyParameterization(ParsedFexFile result) {
        if (!result.getPrompts().isEmpty() || !result.getVariables().isEmpty()) {
            result.getClassification().setParameterized(true);
        }
        if (!result.getRunChains().isEmpty() || !result.getIncludes().isEmpty()) {
            result.getClassification().setSubroutine(false); // It calls others, so it's a parent
        }
    }
}
