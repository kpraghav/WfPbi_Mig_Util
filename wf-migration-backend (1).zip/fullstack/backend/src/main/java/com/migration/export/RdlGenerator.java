package com.migration.export;

import com.migration.converter.ExpressionConverter;
import com.migration.model.ConversionResult;
import com.migration.model.ConversionResult.*;
import com.migration.model.ParsedFexFile;
import com.migration.model.ParsedFexFile.*;
import org.springframework.stereotype.Service;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates valid Microsoft RDL (Report Definition Language) 2016 XML files
 * that can be opened directly in Power BI Report Builder and published
 * to Power BI Report Server (on-prem).
 *
 * RDL Schema: http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition
 *
 * Handles:
 * ─ Data Sources (configurable connection placeholder)
 * ─ Data Sets with field definitions from parsed FEX
 * ─ Report Parameters from ACCEPT/PROMPT/-SET
 * ─ Tablix (table) visuals with column headers and detail rows
 * ─ Row Groups with page-break-before from BY ... PAGE-BREAK
 * ─ Group Headers and Footers with subtotals
 * ─ ACROSS → Column Groups (Matrix)
 * ─ Page Header with HEADING text and report title
 * ─ Page Footer with page numbers, run date, total pages
 * ─ Conditional formatting from SET STYLE WHEN rules
 * ─ Chart visuals from GRAPH FILE requests
 * ─ COMPUTE/RECAP → calculated fields in dataset
 * ─ Multiple requests → multiple report body items
 */
@Service
public class RdlGenerator {

    private static final String RDL_NS = "http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition";
    private static final String RD_NS = "http://schemas.microsoft.com/SQLServer/reporting/reportdesigner";

    private final ExpressionConverter exprConverter;

    public RdlGenerator(ExpressionConverter exprConverter) {
        this.exprConverter = exprConverter;
    }

    /**
     * Generate a complete RDL XML document from a parsed FEX file and its conversion result.
     */
    public byte[] generateRdl(ParsedFexFile fex, ConversionResult conversion) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter w = factory.createXMLStreamWriter(baos, "UTF-8");

            w.writeStartDocument("UTF-8", "1.0");
            w.writeStartElement("Report");
            w.writeAttribute("xmlns", RDL_NS);
            w.writeNamespace("rd", RD_NS);

            writeAutoRefresh(w, 0);
            writeDataSources(w, fex);
            writeDataSets(w, fex);
            writeReportParameters(w, fex);
            writeReportSections(w, fex, conversion);

            // Page setup
            writePage(w, fex);

            // Report-level properties
            writeSimple(w, "ConsumeContainerWhitespace", "true");
            writeSimple(w, "Language", "en-US");

            w.writeEndElement(); // Report
            w.writeEndDocument();
            w.flush();
            w.close();

            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate RDL: " + e.getMessage(), e);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Data Sources
    // ═══════════════════════════════════════════════════════════════
    private void writeDataSources(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        w.writeStartElement("DataSources");

        w.writeStartElement("DataSource");
        w.writeAttribute("Name", "WebFocusDataSource");
        writeSimple(w, "ConnectionProperties", null);
        w.writeStartElement("ConnectionProperties");
        writeSimple(w, "DataProvider", "SQL");
        writeSimple(w, "ConnectString", "Data Source=YOUR_SERVER;Initial Catalog=YOUR_DATABASE");
        writeSimple(w, "IntegratedSecurity", "true");
        w.writeEndElement(); // ConnectionProperties

        w.writeEndElement(); // DataSource
        w.writeEndElement(); // DataSources
    }

    // ═══════════════════════════════════════════════════════════════
    // Data Sets — one per TABLE/GRAPH request
    // ═══════════════════════════════════════════════════════════════
    private void writeDataSets(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        w.writeStartElement("DataSets");

        int dsIdx = 1;
        for (TableRequest req : fex.getRequests()) {
            String dsName = "DS_" + req.getFile() + "_" + dsIdx;

            w.writeStartElement("DataSet");
            w.writeAttribute("Name", dsName);

            // Query
            w.writeStartElement("Query");
            writeSimple(w, "DataSourceName", "WebFocusDataSource");
            writeSimple(w, "CommandText", generateSqlFromRequest(req, fex));
            writeQueryParameters(w, req, fex);
            w.writeEndElement(); // Query

            // Fields
            w.writeStartElement("Fields");
            Set<String> addedFields = new HashSet<>();

            // BY fields first
            for (String by : req.getGroupBy()) {
                if (addedFields.add(by)) writeField(w, by, by, guessFieldType(by, fex));
            }
            // ACROSS fields
            for (String ac : req.getAcrossFields()) {
                if (addedFields.add(ac)) writeField(w, ac, ac, "System.String");
            }
            // Print/aggregation fields
            for (RequestField rf : req.getFields()) {
                String name = rf.getName();
                if (addedFields.add(name)) {
                    String type = rf.getAggregation() != null ? "System.Decimal" : guessFieldType(name, fex);
                    writeField(w, name, name, type);
                }
            }
            // Compute fields
            for (ComputeField cf : req.getComputes()) {
                if (addedFields.add(cf.getField())) writeField(w, cf.getField(), cf.getField(), "System.Decimal");
            }
            // Recap fields
            for (RecapField rf : req.getRecaps()) {
                if (addedFields.add(rf.getField())) writeField(w, rf.getField(), rf.getField(), "System.Decimal");
            }

            w.writeEndElement(); // Fields
            w.writeEndElement(); // DataSet
            dsIdx++;
        }

        w.writeEndElement(); // DataSets
    }

    private void writeField(XMLStreamWriter w, String name, String dataField, String typeName) throws XMLStreamException {
        w.writeStartElement("Field");
        w.writeAttribute("Name", sanitizeName(name));
        writeSimple(w, "DataField", dataField);
        w.writeStartElement("rd:TypeName");
        w.writeCharacters(typeName);
        w.writeEndElement();
        w.writeEndElement();
    }

    private void writeQueryParameters(XMLStreamWriter w, TableRequest req, ParsedFexFile fex) throws XMLStreamException {
        List<String> paramNames = new ArrayList<>();
        for (FilterSpec f : req.getFilters()) {
            if (f.isParameterized()) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("&(\\w+)").matcher(f.getExpression());
                while (m.find()) paramNames.add(m.group(1));
            }
        }
        for (Variable v : fex.getVariables()) paramNames.add(v.getName());

        if (paramNames.isEmpty()) return;

        w.writeStartElement("QueryParameters");
        for (String pn : new LinkedHashSet<>(paramNames)) {
            w.writeStartElement("QueryParameter");
            w.writeAttribute("Name", "@" + pn);
            writeSimple(w, "Value", "=Parameters!" + pn + ".Value");
            w.writeEndElement();
        }
        w.writeEndElement();
    }

    // ═══════════════════════════════════════════════════════════════
    // Report Parameters
    // ═══════════════════════════════════════════════════════════════
    private void writeReportParameters(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        List<Object> allParams = new ArrayList<>();
        allParams.addAll(fex.getPrompts());
        allParams.addAll(fex.getVariables());
        if (allParams.isEmpty()) return;

        w.writeStartElement("ReportParameters");

        // From ACCEPT/PROMPT
        for (PromptSpec p : fex.getPrompts()) {
            String name = p.getParamName() != null ? p.getParamName() : "param_" + p.getLine();
            w.writeStartElement("ReportParameter");
            w.writeAttribute("Name", name);
            writeSimple(w, "DataType", mapParamDataType(p.getParamType()));
            writeSimple(w, "Nullable", "false");
            writeSimple(w, "Prompt", p.getDescription() != null ? p.getDescription() : name);
            if (p.getDefaultValue() != null) {
                w.writeStartElement("DefaultValue");
                w.writeStartElement("Values");
                writeSimple(w, "Value", p.getDefaultValue());
                w.writeEndElement();
                w.writeEndElement();
            }
            if (!p.getAllowedValues().isEmpty()) {
                w.writeStartElement("ValidValues");
                w.writeStartElement("ParameterValues");
                for (String v : p.getAllowedValues()) {
                    w.writeStartElement("ParameterValue");
                    writeSimple(w, "Value", v);
                    writeSimple(w, "Label", v);
                    w.writeEndElement();
                }
                w.writeEndElement();
                w.writeEndElement();
            }
            w.writeEndElement(); // ReportParameter
        }

        // From -SET variables
        for (Variable v : fex.getVariables()) {
            w.writeStartElement("ReportParameter");
            w.writeAttribute("Name", v.getName());
            writeSimple(w, "DataType", mapVarDataType(v.getDataType()));
            writeSimple(w, "Nullable", "false");
            writeSimple(w, "Prompt", v.getName());
            w.writeStartElement("DefaultValue");
            w.writeStartElement("Values");
            writeSimple(w, "Value", v.getValue().replaceAll("^['\"]|['\"]$", ""));
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
        }

        w.writeEndElement(); // ReportParameters
    }

    // ═══════════════════════════════════════════════════════════════
    // Report Sections (Body + Header + Footer)
    // ═══════════════════════════════════════════════════════════════
    private void writeReportSections(XMLStreamWriter w, ParsedFexFile fex, ConversionResult conversion) throws XMLStreamException {
        w.writeStartElement("ReportSections");
        w.writeStartElement("ReportSection");

        // Body
        w.writeStartElement("Body");
        writeSimple(w, "Height", calculateBodyHeight(fex) + "in");

        w.writeStartElement("ReportItems");

        double topOffset = 0.0;
        int reqIdx = 1;

        for (TableRequest req : fex.getRequests()) {
            String dsName = "DS_" + req.getFile() + "_" + reqIdx;

            if (req.getType().equals("GRAPH")) {
                writeChart(w, req, dsName, topOffset);
                topOffset += 4.0;
            } else {
                boolean isMatrix = !req.getAcrossFields().isEmpty();
                if (isMatrix) {
                    writeMatrix(w, req, dsName, fex, topOffset);
                } else {
                    writeTablix(w, req, dsName, fex, topOffset);
                }
                topOffset += estimateTablixHeight(req);
            }
            reqIdx++;
        }

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // Body

        // Page Header
        writePageHeader(w, fex);

        // Page Footer
        writePageFooter(w, fex);

        writeSimple(w, "Width", "10in");

        w.writeEndElement(); // ReportSection
        w.writeEndElement(); // ReportSections
    }

    // ═══════════════════════════════════════════════════════════════
    // Tablix (Standard Table)
    // ═══════════════════════════════════════════════════════════════
    private void writeTablix(XMLStreamWriter w, TableRequest req, String dsName, ParsedFexFile fex, double top) throws XMLStreamException {
        List<RequestField> visibleFields = req.getFields().stream().filter(f -> !f.isNoprint()).collect(Collectors.toList());
        List<ComputeField> computes = req.getComputes();
        int totalCols = visibleFields.size() + computes.size();
        if (totalCols == 0) totalCols = 1;
        double colWidth = Math.min(2.0, 9.5 / totalCols);

        w.writeStartElement("Tablix");
        w.writeAttribute("Name", "Tablix_" + sanitizeName(dsName));

        // TablixBody
        w.writeStartElement("TablixBody");

        // Columns
        w.writeStartElement("TablixColumns");
        for (int c = 0; c < totalCols; c++) {
            w.writeStartElement("TablixColumn");
            writeSimple(w, "Width", String.format("%.2fin", colWidth));
            w.writeEndElement();
        }
        w.writeEndElement(); // TablixColumns

        // Rows
        w.writeStartElement("TablixRows");

        // Header Row
        w.writeStartElement("TablixRow");
        writeSimple(w, "Height", "0.3in");
        w.writeStartElement("TablixCells");
        int colIdx = 0;
        for (RequestField rf : visibleFields) {
            writeTablixHeaderCell(w, rf.getAlias() != null ? rf.getAlias() : rf.getName(), colIdx++);
        }
        for (ComputeField cf : computes) {
            writeTablixHeaderCell(w, cf.getField(), colIdx++);
        }
        w.writeEndElement(); // TablixCells
        w.writeEndElement(); // TablixRow

        // Detail Row
        w.writeStartElement("TablixRow");
        writeSimple(w, "Height", "0.25in");
        w.writeStartElement("TablixCells");
        colIdx = 0;
        for (RequestField rf : visibleFields) {
            String expr = "=Fields!" + sanitizeName(rf.getName()) + ".Value";
            if (rf.getAggregation() != null) {
                expr = "=" + mapAggToRdl(rf.getAggregation()) + "(Fields!" + sanitizeName(rf.getName()) + ".Value)";
            }
            writeTablixDataCell(w, expr, isNumericAgg(rf.getAggregation()), colIdx++, req, rf.getName());
        }
        for (ComputeField cf : computes) {
            writeTablixDataCell(w, "=Fields!" + sanitizeName(cf.getField()) + ".Value", true, colIdx++, req, cf.getField());
        }
        w.writeEndElement(); // TablixCells
        w.writeEndElement(); // TablixRow

        // Group Footer with subtotals (if SUBTOTAL enabled)
        if (req.isSubTotals() && !req.getGroupBy().isEmpty()) {
            w.writeStartElement("TablixRow");
            writeSimple(w, "Height", "0.28in");
            w.writeStartElement("TablixCells");
            colIdx = 0;
            for (RequestField rf : visibleFields) {
                if (colIdx == 0) {
                    writeTablixSubtotalCell(w, "=\"Subtotal\"", false, colIdx++);
                } else if (rf.getAggregation() != null) {
                    String expr = "=" + mapAggToRdl(rf.getAggregation()) + "(Fields!" + sanitizeName(rf.getName()) + ".Value)";
                    writeTablixSubtotalCell(w, expr, true, colIdx++);
                } else {
                    writeTablixSubtotalCell(w, "", false, colIdx++);
                }
            }
            for (ComputeField cf : computes) {
                writeTablixSubtotalCell(w, "=Sum(Fields!" + sanitizeName(cf.getField()) + ".Value)", true, colIdx++);
            }
            w.writeEndElement();
            w.writeEndElement();
        }

        w.writeEndElement(); // TablixRows
        w.writeEndElement(); // TablixBody

        // Column Hierarchy
        w.writeStartElement("TablixColumnHierarchy");
        w.writeStartElement("TablixMembers");
        for (int c = 0; c < totalCols; c++) {
            w.writeStartElement("TablixMember");
            w.writeEndElement();
        }
        w.writeEndElement();
        w.writeEndElement();

        // Row Hierarchy with Groups
        w.writeStartElement("TablixRowHierarchy");
        w.writeStartElement("TablixMembers");

        // Header member (static)
        w.writeStartElement("TablixMember");
        writeSimple(w, "KeepWithGroup", "After");
        writeSimple(w, "RepeatOnNewPage", "true");
        w.writeEndElement();

        // Group members from BY fields
        if (!req.getGroupBy().isEmpty()) {
            writeNestedGroups(w, req, req.getGroupBy(), 0);
        } else {
            // No grouping — just detail
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group");
            w.writeAttribute("Name", "Detail_" + sanitizeName(dsName));
            w.writeEndElement();
            w.writeEndElement();
        }

        // Subtotal footer member
        if (req.isSubTotals() && !req.getGroupBy().isEmpty()) {
            w.writeStartElement("TablixMember");
            writeSimple(w, "KeepWithGroup", "Before");
            w.writeEndElement();
        }

        w.writeEndElement(); // TablixMembers
        w.writeEndElement(); // TablixRowHierarchy

        writeSimple(w, "DataSetName", dsName);
        writeSimple(w, "Top", String.format("%.2fin", top));
        writeSimple(w, "Left", "0.25in");
        writeSimple(w, "Height", String.format("%.2fin", estimateTablixHeight(req)));
        writeSimple(w, "Width", String.format("%.2fin", colWidth * totalCols));

        // Column total
        if (req.isColumnTotal()) {
            writeSimple(w, "NoRowsMessage", "No data available");
        }

        // Style
        w.writeStartElement("Style");
        writeSimple(w, "FontFamily", "Segoe UI");
        writeSimple(w, "FontSize", "9pt");
        w.writeEndElement();

        w.writeEndElement(); // Tablix
    }

    private void writeNestedGroups(XMLStreamWriter w, TableRequest req, List<String> groups, int depth) throws XMLStreamException {
        if (depth >= groups.size()) {
            // Detail row member
            w.writeStartElement("TablixMember");
            w.writeStartElement("Group");
            w.writeAttribute("Name", "Detail");
            w.writeEndElement();
            w.writeEndElement();
            return;
        }

        String groupField = groups.get(depth);
        boolean hasPageBreak = req.getPageBreaks().contains(groupField);

        w.writeStartElement("TablixMember");

        // Group definition
        w.writeStartElement("Group");
        w.writeAttribute("Name", "Group_" + sanitizeName(groupField));
        w.writeStartElement("GroupExpressions");
        w.writeStartElement("GroupExpression");
        w.writeCharacters("=Fields!" + sanitizeName(groupField) + ".Value");
        w.writeEndElement();
        w.writeEndElement();

        // Page break
        if (hasPageBreak) {
            w.writeStartElement("PageBreak");
            writeSimple(w, "BreakLocation", "Between");
            w.writeEndElement();
        }

        w.writeEndElement(); // Group

        // Sort
        w.writeStartElement("SortExpressions");
        w.writeStartElement("SortExpression");
        writeSimple(w, "Value", "=Fields!" + sanitizeName(groupField) + ".Value");
        writeSimple(w, "Direction", "Ascending");
        w.writeEndElement();
        w.writeEndElement();

        // Child members
        w.writeStartElement("TablixMembers");
        writeNestedGroups(w, req, groups, depth + 1);
        w.writeEndElement();

        w.writeEndElement(); // TablixMember
    }

    // ═══════════════════════════════════════════════════════════════
    // Matrix (ACROSS → Column Group)
    // ═══════════════════════════════════════════════════════════════
    private void writeMatrix(XMLStreamWriter w, TableRequest req, String dsName, ParsedFexFile fex, double top) throws XMLStreamException {
        List<RequestField> measures = req.getFields().stream().filter(f -> f.getAggregation() != null).collect(Collectors.toList());
        if (measures.isEmpty()) measures = req.getFields().stream().filter(f -> !f.isNoprint()).collect(Collectors.toList());

        w.writeStartElement("Tablix");
        w.writeAttribute("Name", "Matrix_" + sanitizeName(dsName));

        w.writeStartElement("TablixBody");

        // 2 columns: row label + data
        w.writeStartElement("TablixColumns");
        w.writeStartElement("TablixColumn"); writeSimple(w, "Width", "2in"); w.writeEndElement();
        w.writeStartElement("TablixColumn"); writeSimple(w, "Width", "1.5in"); w.writeEndElement();
        w.writeEndElement();

        // Header row
        w.writeStartElement("TablixRows");
        w.writeStartElement("TablixRow");
        writeSimple(w, "Height", "0.3in");
        w.writeStartElement("TablixCells");
        writeTablixHeaderCell(w, req.getGroupBy().isEmpty() ? "Row" : req.getGroupBy().get(0), 0);
        writeTablixHeaderCell(w, measures.isEmpty() ? "Value" : (measures.get(0).getAlias() != null ? measures.get(0).getAlias() : measures.get(0).getName()), 1);
        w.writeEndElement();
        w.writeEndElement();

        // Data row
        w.writeStartElement("TablixRow");
        writeSimple(w, "Height", "0.25in");
        w.writeStartElement("TablixCells");
        String rowField = req.getGroupBy().isEmpty() ? "Row" : req.getGroupBy().get(0);
        writeTablixDataCell(w, "=Fields!" + sanitizeName(rowField) + ".Value", false, 0, req, rowField);
        if (!measures.isEmpty()) {
            RequestField mf = measures.get(0);
            String expr = "=" + mapAggToRdl(mf.getAggregation() != null ? mf.getAggregation() : "SUM") + "(Fields!" + sanitizeName(mf.getName()) + ".Value)";
            writeTablixDataCell(w, expr, true, 1, req, mf.getName());
        } else {
            writeTablixDataCell(w, "", false, 1, req, "");
        }
        w.writeEndElement();
        w.writeEndElement();

        w.writeEndElement(); // TablixRows
        w.writeEndElement(); // TablixBody

        // Column hierarchy with ACROSS group
        w.writeStartElement("TablixColumnHierarchy");
        w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember"); w.writeEndElement(); // Row label column (static)
        w.writeStartElement("TablixMember");
        w.writeStartElement("Group");
        w.writeAttribute("Name", "ColumnGroup_" + sanitizeName(req.getAcrossFields().get(0)));
        w.writeStartElement("GroupExpressions");
        writeSimple(w, "GroupExpression", "=Fields!" + sanitizeName(req.getAcrossFields().get(0)) + ".Value");
        w.writeEndElement();
        w.writeEndElement(); // Group
        w.writeEndElement(); // TablixMember
        w.writeEndElement();
        w.writeEndElement();

        // Row hierarchy
        w.writeStartElement("TablixRowHierarchy");
        w.writeStartElement("TablixMembers");
        w.writeStartElement("TablixMember");
        writeSimple(w, "KeepWithGroup", "After");
        writeSimple(w, "RepeatOnNewPage", "true");
        w.writeEndElement();
        w.writeStartElement("TablixMember");
        if (!req.getGroupBy().isEmpty()) {
            w.writeStartElement("Group");
            w.writeAttribute("Name", "RowGroup_" + sanitizeName(req.getGroupBy().get(0)));
            w.writeStartElement("GroupExpressions");
            writeSimple(w, "GroupExpression", "=Fields!" + sanitizeName(req.getGroupBy().get(0)) + ".Value");
            w.writeEndElement();
            w.writeEndElement();
        } else {
            w.writeStartElement("Group"); w.writeAttribute("Name", "Detail"); w.writeEndElement();
        }
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        writeSimple(w, "DataSetName", dsName);
        writeSimple(w, "Top", String.format("%.2fin", top));
        writeSimple(w, "Left", "0.25in");
        writeSimple(w, "Height", "2in");
        writeSimple(w, "Width", "6in");

        w.writeEndElement(); // Tablix
    }

    // ═══════════════════════════════════════════════════════════════
    // Chart (GRAPH FILE)
    // ═══════════════════════════════════════════════════════════════
    private void writeChart(XMLStreamWriter w, TableRequest req, String dsName, double top) throws XMLStreamException {
        String chartType = "Column";
        if (req.getGraphConfig() != null && req.getGraphConfig().getGraphType() != null) {
            chartType = switch (req.getGraphConfig().getGraphType().toUpperCase()) {
                case "PIE" -> "Shape";
                case "LINE" -> "Line";
                case "BAR", "VBAR" -> "Column";
                case "HBAR" -> "Bar";
                case "AREA" -> "Area";
                case "SCATTER", "BUBBLE" -> "Scatter";
                default -> "Column";
            };
        }

        w.writeStartElement("Chart");
        w.writeAttribute("Name", "Chart_" + sanitizeName(dsName));

        w.writeStartElement("ChartCategoryHierarchy");
        w.writeStartElement("ChartMembers");
        w.writeStartElement("ChartMember");
        if (!req.getGroupBy().isEmpty()) {
            w.writeStartElement("Group");
            w.writeAttribute("Name", "ChartCatGroup");
            w.writeStartElement("GroupExpressions");
            writeSimple(w, "GroupExpression", "=Fields!" + sanitizeName(req.getGroupBy().get(0)) + ".Value");
            w.writeEndElement();
            w.writeEndElement();
        }
        writeSimple(w, "Label", !req.getGroupBy().isEmpty() ? "=Fields!" + sanitizeName(req.getGroupBy().get(0)) + ".Value" : "Category");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        w.writeStartElement("ChartSeriesHierarchy");
        w.writeStartElement("ChartMembers");
        w.writeStartElement("ChartMember"); w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        w.writeStartElement("ChartData");
        w.writeStartElement("ChartSeriesCollection");

        for (RequestField rf : req.getFields()) {
            if (rf.getAggregation() != null) {
                w.writeStartElement("ChartSeries");
                w.writeStartElement("ChartDataPoints");
                w.writeStartElement("ChartDataPoint");
                w.writeStartElement("ChartDataPointValues");
                writeSimple(w, "Y", "=Sum(Fields!" + sanitizeName(rf.getName()) + ".Value)");
                w.writeEndElement();
                w.writeStartElement("ChartDataLabel");
                writeSimple(w, "Visible", "false");
                w.writeEndElement();
                w.writeEndElement();
                w.writeEndElement();
                writeSimple(w, "Type", chartType);
                w.writeEndElement();
            }
        }

        w.writeEndElement();
        w.writeEndElement();

        // Chart areas and legends
        w.writeStartElement("ChartAreas");
        w.writeStartElement("ChartArea");
        w.writeAttribute("Name", "Default");
        w.writeEndElement();
        w.writeEndElement();

        w.writeStartElement("ChartLegends");
        w.writeStartElement("ChartLegend");
        w.writeAttribute("Name", "Default");
        w.writeStartElement("Style"); w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();

        if (!req.getHeadings().isEmpty()) {
            w.writeStartElement("ChartTitles");
            w.writeStartElement("ChartTitle");
            writeSimple(w, "Caption", cleanHeadingText(req.getHeadings().get(0)));
            w.writeEndElement();
            w.writeEndElement();
        }

        writeSimple(w, "DataSetName", dsName);
        writeSimple(w, "Top", String.format("%.2fin", top));
        writeSimple(w, "Left", "0.25in");
        writeSimple(w, "Height", "3.5in");
        writeSimple(w, "Width", "8in");

        w.writeEndElement(); // Chart
    }

    // ═══════════════════════════════════════════════════════════════
    // Page Header
    // ═══════════════════════════════════════════════════════════════
    private void writePageHeader(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        // Collect all headings
        List<String> headings = new ArrayList<>();
        List<String> subHeadings = new ArrayList<>();
        for (TableRequest req : fex.getRequests()) {
            headings.addAll(req.getHeadings());
            subHeadings.addAll(req.getSubHeadings());
        }
        if (headings.isEmpty() && subHeadings.isEmpty()) return;

        w.writeStartElement("PageHeader");
        writeSimple(w, "Height", "0.6in");
        writeSimple(w, "PrintOnFirstPage", "true");
        writeSimple(w, "PrintOnLastPage", "true");

        w.writeStartElement("ReportItems");

        // Main heading
        if (!headings.isEmpty()) {
            w.writeStartElement("Textbox");
            w.writeAttribute("Name", "PageHeaderTitle");
            w.writeStartElement("Paragraphs");
            w.writeStartElement("Paragraph");
            w.writeStartElement("TextRuns");
            w.writeStartElement("TextRun");
            writeSimple(w, "Value", convertHeadingToExpression(headings.get(0), fex));
            w.writeStartElement("Style");
            writeSimple(w, "FontFamily", "Segoe UI");
            writeSimple(w, "FontSize", "14pt");
            writeSimple(w, "FontWeight", "Bold");
            w.writeEndElement(); // Style
            w.writeEndElement(); // TextRun
            w.writeEndElement();
            w.writeStartElement("Style");
            writeSimple(w, "TextAlign", "Center");
            w.writeEndElement();
            w.writeEndElement(); // Paragraph
            w.writeEndElement();
            writeSimple(w, "Top", "0in");
            writeSimple(w, "Left", "0in");
            writeSimple(w, "Height", "0.35in");
            writeSimple(w, "Width", "9.5in");
            w.writeStartElement("Style");
            writeSimple(w, "VerticalAlign", "Middle");
            w.writeEndElement();
            w.writeEndElement(); // Textbox
        }

        // Sub heading
        if (!subHeadings.isEmpty()) {
            w.writeStartElement("Textbox");
            w.writeAttribute("Name", "PageSubHeader");
            w.writeStartElement("Paragraphs");
            w.writeStartElement("Paragraph");
            w.writeStartElement("TextRuns");
            w.writeStartElement("TextRun");
            writeSimple(w, "Value", convertHeadingToExpression(subHeadings.get(0), fex));
            w.writeStartElement("Style");
            writeSimple(w, "FontSize", "9pt");
            writeSimple(w, "FontStyle", "Italic");
            writeSimple(w, "Color", "#666666");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            w.writeStartElement("Style");
            writeSimple(w, "TextAlign", "Center");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            writeSimple(w, "Top", "0.35in");
            writeSimple(w, "Left", "0in");
            writeSimple(w, "Height", "0.25in");
            writeSimple(w, "Width", "9.5in");
            w.writeEndElement();
        }

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // PageHeader
    }

    // ═══════════════════════════════════════════════════════════════
    // Page Footer
    // ═══════════════════════════════════════════════════════════════
    private void writePageFooter(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        List<String> footings = new ArrayList<>();
        boolean hasPageNum = false, hasTotalPages = false, hasRunDate = false;

        for (TableRequest req : fex.getRequests()) {
            footings.addAll(req.getFootings());
            PaginationConfig pg = req.getPagination();
            if (pg.isHasPageNumbering()) hasPageNum = true;
            if (pg.isHasTotalPages()) hasTotalPages = true;
            if (pg.isHasRunDate()) hasRunDate = true;
        }

        if (footings.isEmpty() && !hasPageNum && !hasRunDate) return;

        w.writeStartElement("PageFooter");
        writeSimple(w, "Height", "0.4in");
        writeSimple(w, "PrintOnFirstPage", "true");
        writeSimple(w, "PrintOnLastPage", "true");

        w.writeStartElement("ReportItems");

        // Left: footing text or run date
        if (hasRunDate || !footings.isEmpty()) {
            w.writeStartElement("Textbox");
            w.writeAttribute("Name", "FooterLeft");
            w.writeStartElement("Paragraphs");
            w.writeStartElement("Paragraph");
            w.writeStartElement("TextRuns");
            w.writeStartElement("TextRun");
            if (!footings.isEmpty()) {
                writeSimple(w, "Value", convertFootingToExpression(footings.get(0)));
            } else {
                writeSimple(w, "Value", "=\"Generated: \" & Format(Now(), \"yyyy-MM-dd HH:mm\")");
            }
            w.writeStartElement("Style");
            writeSimple(w, "FontSize", "8pt");
            writeSimple(w, "Color", "#999999");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            writeSimple(w, "Top", "0.05in");
            writeSimple(w, "Left", "0in");
            writeSimple(w, "Height", "0.3in");
            writeSimple(w, "Width", "4in");
            w.writeEndElement();
        }

        // Right: page numbers
        if (hasPageNum) {
            w.writeStartElement("Textbox");
            w.writeAttribute("Name", "FooterPageNum");
            w.writeStartElement("Paragraphs");
            w.writeStartElement("Paragraph");
            w.writeStartElement("TextRuns");
            w.writeStartElement("TextRun");
            String pageExpr = hasTotalPages
                ? "=\"Page \" & Globals!PageNumber & \" of \" & Globals!TotalPages"
                : "=\"Page \" & Globals!PageNumber";
            writeSimple(w, "Value", pageExpr);
            w.writeStartElement("Style");
            writeSimple(w, "FontSize", "8pt");
            writeSimple(w, "Color", "#999999");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            w.writeStartElement("Style");
            writeSimple(w, "TextAlign", "Right");
            w.writeEndElement();
            w.writeEndElement();
            w.writeEndElement();
            writeSimple(w, "Top", "0.05in");
            writeSimple(w, "Left", "5.5in");
            writeSimple(w, "Height", "0.3in");
            writeSimple(w, "Width", "4in");
            w.writeEndElement();
        }

        w.writeEndElement(); // ReportItems
        w.writeEndElement(); // PageFooter
    }

    // ═══════════════════════════════════════════════════════════════
    // Page Setup
    // ═══════════════════════════════════════════════════════════════
    private void writePage(XMLStreamWriter w, ParsedFexFile fex) throws XMLStreamException {
        w.writeStartElement("Page");
        writeSimple(w, "PageHeight", "11in");
        writeSimple(w, "PageWidth", "8.5in");
        writeSimple(w, "LeftMargin", "0.5in");
        writeSimple(w, "RightMargin", "0.5in");
        writeSimple(w, "TopMargin", "0.5in");
        writeSimple(w, "BottomMargin", "0.5in");
        writeSimple(w, "ColumnSpacing", "0.13in");
        writeSimple(w, "Style", null);
        w.writeStartElement("Style"); w.writeEndElement();
        w.writeEndElement();
    }

    // ═══════════════════════════════════════════════════════════════
    // Cell Helpers
    // ═══════════════════════════════════════════════════════════════
    private void writeTablixHeaderCell(XMLStreamWriter w, String label, int colIdx) throws XMLStreamException {
        w.writeStartElement("TablixCell");
        w.writeStartElement("CellContents");
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "Header_" + sanitizeName(label) + "_" + colIdx);
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        writeSimple(w, "Value", label);
        w.writeStartElement("Style");
        writeSimple(w, "FontFamily", "Segoe UI");
        writeSimple(w, "FontSize", "9pt");
        writeSimple(w, "FontWeight", "Bold");
        writeSimple(w, "Color", "White");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("Style");
        writeSimple(w, "BackgroundColor", "#4472C4");
        writeSimple(w, "PaddingLeft", "4pt");
        writeSimple(w, "PaddingRight", "4pt");
        writeSimple(w, "PaddingTop", "2pt");
        writeSimple(w, "PaddingBottom", "2pt");
        writeBorders(w);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
    }

    private void writeTablixDataCell(XMLStreamWriter w, String expression, boolean isNumeric, int colIdx, TableRequest req, String fieldName) throws XMLStreamException {
        w.writeStartElement("TablixCell");
        w.writeStartElement("CellContents");
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "Data_" + sanitizeName(fieldName) + "_" + colIdx);
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        writeSimple(w, "Value", expression);
        w.writeStartElement("Style");
        writeSimple(w, "FontFamily", "Segoe UI");
        writeSimple(w, "FontSize", "8pt");
        if (isNumeric) writeSimple(w, "Format", "#,##0.00");
        // Conditional formatting from style rules
        writeConditionalStyle(w, req, fieldName);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("Style");
        if (isNumeric) writeSimple(w, "TextAlign", "Right");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("Style");
        writeSimple(w, "PaddingLeft", "4pt");
        writeSimple(w, "PaddingRight", "4pt");
        writeSimple(w, "PaddingTop", "2pt");
        writeSimple(w, "PaddingBottom", "2pt");
        writeBorders(w);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
    }

    private void writeTablixSubtotalCell(XMLStreamWriter w, String expression, boolean isNumeric, int colIdx) throws XMLStreamException {
        w.writeStartElement("TablixCell");
        w.writeStartElement("CellContents");
        w.writeStartElement("Textbox");
        w.writeAttribute("Name", "Subtotal_" + colIdx);
        w.writeStartElement("Paragraphs");
        w.writeStartElement("Paragraph");
        w.writeStartElement("TextRuns");
        w.writeStartElement("TextRun");
        writeSimple(w, "Value", expression);
        w.writeStartElement("Style");
        writeSimple(w, "FontWeight", "Bold");
        writeSimple(w, "FontSize", "8pt");
        if (isNumeric) writeSimple(w, "Format", "#,##0.00");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("Style");
        if (isNumeric) writeSimple(w, "TextAlign", "Right");
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeStartElement("Style");
        writeSimple(w, "BackgroundColor", "#E2EFDA");
        writeSimple(w, "PaddingLeft", "4pt");
        writeSimple(w, "PaddingRight", "4pt");
        writeBorders(w);
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
        w.writeEndElement();
    }

    private void writeConditionalStyle(XMLStreamWriter w, TableRequest req, String fieldName) throws XMLStreamException {
        for (StyleRule rule : req.getStyleRules()) {
            if (rule.getTargetField() != null && rule.getTargetField().equalsIgnoreCase(fieldName) && rule.getCondition() != null) {
                String bgColor = rule.getProperties().get("BACKCOLOR");
                if (bgColor != null) {
                    writeSimple(w, "BackgroundColor", exprConverter.convertColor(bgColor));
                }
            }
        }
    }

    private void writeBorders(XMLStreamWriter w) throws XMLStreamException {
        w.writeStartElement("Border");
        writeSimple(w, "Style", "Solid");
        writeSimple(w, "Width", "0.5pt");
        writeSimple(w, "Color", "#C0C0C0");
        w.writeEndElement();
    }

    // ═══════════════════════════════════════════════════════════════
    // SQL Generation from FEX request
    // ═══════════════════════════════════════════════════════════════
    private String generateSqlFromRequest(TableRequest req, ParsedFexFile fex) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ");

        List<String> selectCols = new ArrayList<>();
        for (String by : req.getGroupBy()) selectCols.add(by);
        for (String ac : req.getAcrossFields()) {
            if (!selectCols.contains(ac)) selectCols.add(ac);
        }
        for (RequestField rf : req.getFields()) {
            String col = rf.getName();
            if (rf.getAggregation() != null && !selectCols.contains(col)) {
                selectCols.add(col);
            } else if (!selectCols.contains(col)) {
                selectCols.add(col);
            }
        }
        for (ComputeField cf : req.getComputes()) {
            if (!selectCols.contains(cf.getField())) selectCols.add(cf.getField());
        }

        if (selectCols.isEmpty()) selectCols.add("*");
        sql.append(String.join(", ", selectCols));
        sql.append("\nFROM dbo.").append(req.getFile());

        // WHERE clauses
        List<String> wheres = new ArrayList<>();
        for (FilterSpec f : req.getFilters()) {
            String expr = f.getExpression().replaceAll("(?i)^(WHERE|IF)\\s+", "").trim();
            expr = expr.replaceAll("(?i)\\bEQ\\b", "=").replaceAll("(?i)\\bNE\\b", "<>")
                .replaceAll("(?i)\\bGT\\b", ">").replaceAll("(?i)\\bLT\\b", "<")
                .replaceAll("(?i)\\bGE\\b", ">=").replaceAll("(?i)\\bLE\\b", "<=")
                .replaceAll("(?i)\\bAND\\b", "AND").replaceAll("(?i)\\bOR\\b", "OR");
            // Replace &var with @var for SQL parameters
            expr = expr.replaceAll("&(\\w+)", "@$1");
            wheres.add(expr);
        }
        if (!wheres.isEmpty()) {
            sql.append("\nWHERE ").append(String.join("\n  AND ", wheres));
        }

        return sql.toString();
    }

    // ═══════════════════════════════════════════════════════════════
    // Heading/Footing expression conversion
    // ═══════════════════════════════════════════════════════════════
    private String convertHeadingToExpression(String heading, ParsedFexFile fex) {
        String clean = heading.replaceAll("^[\"']|[\"']$", "").trim();
        boolean hasExpression = clean.contains("&") || clean.contains("<");

        if (!hasExpression) return clean;

        // Convert to RDL expression
        StringBuilder expr = new StringBuilder("=");
        String[] parts = clean.split("(<[^>]+>|&\\w+)");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(<[^>]+>|&\\w+)").matcher(clean);
        List<String> tokens = new ArrayList<>();
        List<String> vars = new ArrayList<>();
        int lastEnd = 0;

        while (m.find()) {
            if (m.start() > lastEnd) tokens.add("\"" + clean.substring(lastEnd, m.start()) + "\"");
            String var = m.group();
            if (var.startsWith("&")) {
                tokens.add("Parameters!" + var.substring(1) + ".Value");
            } else if (var.equalsIgnoreCase("<TABPAGENO>")) {
                tokens.add("Globals!PageNumber");
            } else if (var.equalsIgnoreCase("<TABLASTPAGE>")) {
                tokens.add("Globals!TotalPages");
            } else if (var.equalsIgnoreCase("<TOD>") || var.equalsIgnoreCase("<D>")) {
                tokens.add("Format(Now(), \"yyyy-MM-dd HH:mm\")");
            } else {
                tokens.add("\"" + var + "\"");
            }
            lastEnd = m.end();
        }
        if (lastEnd < clean.length()) tokens.add("\"" + clean.substring(lastEnd) + "\"");

        return "=" + String.join(" & ", tokens);
    }

    private String convertFootingToExpression(String footing) {
        String clean = footing.replaceAll("^[\"']|[\"']$", "").trim();
        clean = clean.replace("<TABPAGENO>", "\" & Globals!PageNumber & \"");
        clean = clean.replace("<TABLASTPAGE>", "\" & Globals!TotalPages & \"");
        clean = clean.replace("<TOD>", "\" & Format(Now(), \"yyyy-MM-dd HH:mm\") & \"");
        return "=\"" + clean + "\"";
    }

    private String cleanHeadingText(String heading) {
        return heading.replaceAll("^[\"']|[\"']$", "").replaceAll("&\\w+", "").replaceAll("<[^>]+>", "").trim();
    }

    // ═══════════════════════════════════════════════════════════════
    // Utility
    // ═══════════════════════════════════════════════════════════════
    private void writeSimple(XMLStreamWriter w, String name, String value) throws XMLStreamException {
        if (value == null) return;
        w.writeStartElement(name);
        w.writeCharacters(value);
        w.writeEndElement();
    }

    private void writeAutoRefresh(XMLStreamWriter w, int seconds) throws XMLStreamException {
        writeSimple(w, "AutoRefresh", String.valueOf(seconds));
    }

    private String sanitizeName(String name) {
        return name.replaceAll("[^a-zA-Z0-9_]", "_");
    }

    private String mapAggToRdl(String agg) {
        if (agg == null) return "First";
        return switch (agg.toUpperCase()) {
            case "SUM" -> "Sum";
            case "COUNT", "CNT" -> "Count";
            case "AVG" -> "Avg";
            case "MIN" -> "Min";
            case "MAX" -> "Max";
            case "FIRST" -> "First";
            case "LAST" -> "Last";
            default -> "Sum";
        };
    }

    private boolean isNumericAgg(String agg) {
        return agg != null && Set.of("SUM", "COUNT", "CNT", "AVG", "MIN", "MAX", "PCT").contains(agg.toUpperCase());
    }

    private String guessFieldType(String fieldName, ParsedFexFile fex) {
        // Check defines for format hints
        for (DefineField def : fex.getDefines()) {
            if (def.getField().equalsIgnoreCase(fieldName) && def.getFormat() != null) {
                if (def.getFormat().startsWith("A")) return "System.String";
                if (def.getFormat().startsWith("I")) return "System.Int32";
                if (def.getFormat().startsWith("D") || def.getFormat().startsWith("P")) return "System.Decimal";
            }
        }
        return "System.String"; // Safe default
    }

    private String mapParamDataType(String wfType) {
        if (wfType == null) return "String";
        return switch (wfType.toUpperCase()) {
            case "INTEGER", "I", "INT" -> "Integer";
            case "FLOAT", "DOUBLE", "D", "P" -> "Float";
            case "DATE", "YYMD" -> "DateTime";
            default -> "String";
        };
    }

    private String mapVarDataType(String type) {
        if (type == null) return "String";
        return switch (type) { case "INTEGER" -> "Integer"; case "DECIMAL" -> "Float"; default -> "String"; };
    }

    private double calculateBodyHeight(ParsedFexFile fex) {
        double h = 0;
        for (TableRequest req : fex.getRequests()) {
            h += req.getType().equals("GRAPH") ? 4.0 : estimateTablixHeight(req);
        }
        return Math.max(h, 2.0);
    }

    private double estimateTablixHeight(TableRequest req) {
        int rows = 2; // header + detail
        if (req.isSubTotals()) rows++;
        rows += req.getGroupBy().size(); // group headers
        return Math.max(0.3 * rows + 0.5, 1.5);
    }
}
