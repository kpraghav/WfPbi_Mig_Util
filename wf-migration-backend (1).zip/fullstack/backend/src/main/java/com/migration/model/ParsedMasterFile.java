package com.migration.model;

import java.util.*;

/**
 * Comprehensive model for WebFocus Master File (.mas).
 * Covers: Multi-segment hierarchies, cross-references, all data types,
 * DBA access files, suffix types, virtual fields, and DEFINE in master.
 */
public class ParsedMasterFile {
    private String fileName;
    private final String type = "mas";
    private int rawLineCount;
    private String accessFile;
    private String suffix;            // FIX, FOCUS, DB2, ORACLE, SQLSVR, ODBC, REST, XML, JSON
    private String connection;        // Connection string / DSN
    private List<Segment> segments = new ArrayList<>();
    private List<MasterField> fields = new ArrayList<>();
    private List<IndexSpec> indices = new ArrayList<>();
    private List<AliasSpec> aliases = new ArrayList<>();
    private List<DefineInMaster> defines = new ArrayList<>();  // DEFINE within master
    private List<AcceptInMaster> accepts = new ArrayList<>();  // ACCEPT in master
    private DBAConfig dbaConfig;
    private List<String> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();

    // Getters/Setters
    public String getFileName() { return fileName; }
    public void setFileName(String f) { this.fileName = f; }
    public String getType() { return type; }
    public int getRawLineCount() { return rawLineCount; }
    public void setRawLineCount(int n) { this.rawLineCount = n; }
    public String getAccessFile() { return accessFile; }
    public void setAccessFile(String a) { this.accessFile = a; }
    public String getSuffix() { return suffix; }
    public void setSuffix(String s) { this.suffix = s; }
    public String getConnection() { return connection; }
    public void setConnection(String c) { this.connection = c; }
    public List<Segment> getSegments() { return segments; }
    public List<MasterField> getFields() { return fields; }
    public List<IndexSpec> getIndices() { return indices; }
    public List<AliasSpec> getAliases() { return aliases; }
    public List<DefineInMaster> getDefines() { return defines; }
    public List<AcceptInMaster> getAccepts() { return accepts; }
    public DBAConfig getDbaConfig() { return dbaConfig; }
    public void setDbaConfig(DBAConfig d) { this.dbaConfig = d; }
    public List<String> getErrors() { return errors; }
    public List<String> getWarnings() { return warnings; }

    public static class Segment {
        private String name;
        private String parent;
        private String segType;          // S1, S2, KU, KM, DKU, DKM
        private String tableName;        // physical table name for RDBMS
        private boolean isCrossRef;      // CRFILE
        private String crossRefFile;
        private List<MasterField> fields = new ArrayList<>();

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getParent() { return parent; }
        public void setParent(String p) { this.parent = p; }
        public String getSegType() { return segType; }
        public void setSegType(String s) { this.segType = s; }
        public String getTableName() { return tableName; }
        public void setTableName(String t) { this.tableName = t; }
        public boolean isCrossRef() { return isCrossRef; }
        public void setCrossRef(boolean c) { this.isCrossRef = c; }
        public String getCrossRefFile() { return crossRefFile; }
        public void setCrossRefFile(String c) { this.crossRefFile = c; }
        public List<MasterField> getFields() { return fields; }
    }

    public static class MasterField {
        private String name;
        private String alias;
        private String format;
        private String dataType;         // ALPHANUMERIC, INTEGER, PACKED, DOUBLE, DATE, DATETIME
        private Integer length;
        private Integer decimals;
        private String description;
        private String title;
        private int line;
        private String segment;
        private String missing;          // ON, OFF
        private boolean isVirtual;       // Virtual field
        private String actualName;       // ACTUAL= physical column name
        private String usage;            // DISPLAY, FILTER, SORT, KEY
        private String defaultValue;
        private boolean isRequired;
        private String validationRule;

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getAlias() { return alias; }
        public void setAlias(String a) { this.alias = a; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getDataType() { return dataType; }
        public void setDataType(String d) { this.dataType = d; }
        public Integer getLength() { return length; }
        public void setLength(Integer l) { this.length = l; }
        public Integer getDecimals() { return decimals; }
        public void setDecimals(Integer d) { this.decimals = d; }
        public String getDescription() { return description; }
        public void setDescription(String d) { this.description = d; }
        public String getTitle() { return title; }
        public void setTitle(String t) { this.title = t; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getSegment() { return segment; }
        public void setSegment(String s) { this.segment = s; }
        public String getMissing() { return missing; }
        public void setMissing(String m) { this.missing = m; }
        public boolean isVirtual() { return isVirtual; }
        public void setVirtual(boolean v) { this.isVirtual = v; }
        public String getActualName() { return actualName; }
        public void setActualName(String a) { this.actualName = a; }
        public String getUsage() { return usage; }
        public void setUsage(String u) { this.usage = u; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
        public boolean isRequired() { return isRequired; }
        public void setRequired(boolean r) { this.isRequired = r; }
        public String getValidationRule() { return validationRule; }
        public void setValidationRule(String v) { this.validationRule = v; }
    }

    public static class IndexSpec {
        private int line;
        private String text;
        private String fieldName;
        private boolean isPrimary;
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
        public String getText() { return text; }
        public void setText(String t) { this.text = t; }
        public String getFieldName() { return fieldName; }
        public void setFieldName(String f) { this.fieldName = f; }
        public boolean isPrimary() { return isPrimary; }
        public void setPrimary(boolean p) { this.isPrimary = p; }
    }

    public static class AliasSpec {
        private String name;
        private int line;
        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public int getLine() { return line; }
        public void setLine(int l) { this.line = l; }
    }

    public static class DefineInMaster {
        private String field;
        private String format;
        private String expression;
        public String getField() { return field; }
        public void setField(String f) { this.field = f; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public String getExpression() { return expression; }
        public void setExpression(String e) { this.expression = e; }
    }

    public static class AcceptInMaster {
        private String paramName;
        private String paramType;
        private String prompt;
        private String defaultValue;
        public String getParamName() { return paramName; }
        public void setParamName(String p) { this.paramName = p; }
        public String getParamType() { return paramType; }
        public void setParamType(String t) { this.paramType = t; }
        public String getPrompt() { return prompt; }
        public void setPrompt(String p) { this.prompt = p; }
        public String getDefaultValue() { return defaultValue; }
        public void setDefaultValue(String d) { this.defaultValue = d; }
    }

    public static class DBAConfig {
        private String dbType;        // DB2, ORACLE, SQLSVR, ODBC
        private String connectionName;
        private String schema;
        private String catalog;
        private String tablespace;
        public String getDbType() { return dbType; }
        public void setDbType(String d) { this.dbType = d; }
        public String getConnectionName() { return connectionName; }
        public void setConnectionName(String c) { this.connectionName = c; }
        public String getSchema() { return schema; }
        public void setSchema(String s) { this.schema = s; }
        public String getCatalog() { return catalog; }
        public void setCatalog(String c) { this.catalog = c; }
        public String getTablespace() { return tablespace; }
        public void setTablespace(String t) { this.tablespace = t; }
    }
}
