package com.migration.model;

import java.time.LocalDateTime;
import java.util.*;

public class MigrationResponse {
    private String status;
    private LocalDateTime timestamp = LocalDateTime.now();
    private List<Object> parsedFiles = new ArrayList<>();
    private List<ConversionResult> conversions = new ArrayList<>();
    private MigrationSummary summary;
    private FeatureCoverage featureCoverage;
    private List<String> errors = new ArrayList<>();

    public String getStatus() { return status; }
    public void setStatus(String s) { this.status = s; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public List<Object> getParsedFiles() { return parsedFiles; }
    public List<ConversionResult> getConversions() { return conversions; }
    public MigrationSummary getSummary() { return summary; }
    public void setSummary(MigrationSummary s) { this.summary = s; }
    public FeatureCoverage getFeatureCoverage() { return featureCoverage; }
    public void setFeatureCoverage(FeatureCoverage f) { this.featureCoverage = f; }
    public List<String> getErrors() { return errors; }

    public static class MigrationSummary {
        private int totalFiles;
        private int totalMappings;
        private int convertedMappings;
        private int reviewMappings;
        private int unsupportedMappings;
        private int avgConfidence;
        private Map<String, Integer> byCategory = new LinkedHashMap<>();
        private Map<String, Integer> byClassification = new LinkedHashMap<>();

        public int getTotalFiles() { return totalFiles; }
        public void setTotalFiles(int t) { this.totalFiles = t; }
        public int getTotalMappings() { return totalMappings; }
        public void setTotalMappings(int t) { this.totalMappings = t; }
        public int getConvertedMappings() { return convertedMappings; }
        public void setConvertedMappings(int c) { this.convertedMappings = c; }
        public int getReviewMappings() { return reviewMappings; }
        public void setReviewMappings(int r) { this.reviewMappings = r; }
        public int getUnsupportedMappings() { return unsupportedMappings; }
        public void setUnsupportedMappings(int u) { this.unsupportedMappings = u; }
        public int getAvgConfidence() { return avgConfidence; }
        public void setAvgConfidence(int a) { this.avgConfidence = a; }
        public Map<String, Integer> getByCategory() { return byCategory; }
        public Map<String, Integer> getByClassification() { return byClassification; }
    }

    public static class FeatureCoverage {
        private boolean paginatedReports;
        private boolean selfService;
        private boolean activeReports;
        private boolean dashboards;
        private boolean drillDown;
        private boolean conditionalFormatting;
        private boolean parameters;
        private boolean holdChains;
        private boolean crossTab;
        private boolean dialogueManager;

        public boolean isPaginatedReports() { return paginatedReports; }
        public void setPaginatedReports(boolean p) { this.paginatedReports = p; }
        public boolean isSelfService() { return selfService; }
        public void setSelfService(boolean s) { this.selfService = s; }
        public boolean isActiveReports() { return activeReports; }
        public void setActiveReports(boolean a) { this.activeReports = a; }
        public boolean isDashboards() { return dashboards; }
        public void setDashboards(boolean d) { this.dashboards = d; }
        public boolean isDrillDown() { return drillDown; }
        public void setDrillDown(boolean d) { this.drillDown = d; }
        public boolean isConditionalFormatting() { return conditionalFormatting; }
        public void setConditionalFormatting(boolean c) { this.conditionalFormatting = c; }
        public boolean isParameters() { return parameters; }
        public void setParameters(boolean p) { this.parameters = p; }
        public boolean isHoldChains() { return holdChains; }
        public void setHoldChains(boolean h) { this.holdChains = h; }
        public boolean isCrossTab() { return crossTab; }
        public void setCrossTab(boolean c) { this.crossTab = c; }
        public boolean isDialogueManager() { return dialogueManager; }
        public void setDialogueManager(boolean d) { this.dialogueManager = d; }
    }
}
